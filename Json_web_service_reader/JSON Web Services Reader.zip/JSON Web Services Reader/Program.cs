﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;
using System.Data;
using BMC.ARSystem;
using System.Diagnostics;
using System.Reflection;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using System.Xml.Linq;
using System.Collections;
using Newtonsoft.Json.Linq;
using NLog;
using NLog.Common;

namespace JSON_Web_Services_Reader
{
    class Program
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();
        //Initialize the remedy class and httpclient
        private HttpClient httpClient;
        //Declare field IDs, these are required to be "public static" for purposes of reflection
        const string departmentalDataForm = "departmentalData-tempForm";
        public static uint STATUS = 7;
        public static uint REQUEST_ID = 1;
        public static uint setId = 536870913;
        public static uint deptId = 536870914;
        public static uint effDt = 536870916;
        public static uint effDtStr = 536870915;
        public static uint effStatus = 536870920;
        public static uint descr = 536870919;
        public static uint descrShort = 536870918;
        public static uint descrLong = 536870917;
        public static uint managerName = 536870921;
        public static uint accountingOwner = 536870922;
        public static uint SysStatus = 536870923;

        static void Main(string[] args)
        {
            logger.Info("Start Time: " + DateTime.Now.ToString());
            List<Task> tasks = new List<Task>();
            //Task[] tasks = new Task[1];
            //logIntoARServer() logs us into the AR Server with the defined credentials in app.config
            BMC.ARSystem.Server ARServer = logIntoARServer();
            //creates a new instance of this program
            Program prog = new Program();            

            //Run each program in a try so that if one fails, the other will still succeed

            try
            {
                //prog.obtainDeptInformation(ARServer); //Currently this is not being used because the WSDL for departmental information is not production and still changing
            }
            catch(Exception e)
            {
                logger.Error(e);
            }
            try
            {
                tasks.Add(prog.obtainServiceInformation(ARServer)); //This is the function that uses JSON to obtain service information istead of XML
                //tasks.Add(prog.obtainDeptInformation(ARServer)); //This is the function that will obtain dept information from PS
            }
            catch (Exception e)
            {
                logger.Error(e);
            }            
            try
            {
                Task.WaitAll(tasks.ToArray()); 
            }
            catch (AggregateException e)
            {
                logger.Error("The following exceptions were thrown by Task.WaitAll():");
                for (int j = 0; j < e.InnerExceptions.Count; j++)
                {
                    logger.Error("\n-------------------------------------------------\n{0}", e.InnerExceptions[j].ToString());
                }
            }

            //Console.Read();
            //****NO LONGER USED*****//
            //prog.ReadXML(ARServer); //This ReadXML function uses XML that Keith puts out in lieu of JSON. I am going to use the JSON instead
        }
        #region Remedy Authentication
        /**
        * Method for Logging into the AR Server, currently credentials are provided by the appconfig
        * **/
        protected static BMC.ARSystem.Server logIntoARServer()
        {
            BMC.ARSystem.Server ARServer = new BMC.ARSystem.Server();
            string username = System.Configuration.ConfigurationManager.AppSettings["RemedyUsername"];
            string password = System.Configuration.ConfigurationManager.AppSettings["RemedyPassword"];
            string server = System.Configuration.ConfigurationManager.AppSettings["RemedyServer"];
            try
            {
                ARServer.Login(server, username, password);
                logger.Debug("Logged into ARServer successfully");
                ARServer.SetSessionConfiguration(9, 1);
                bool isAdmin, isSubAdmin, isCustomize;
                ARServer.VerifyUser(out isAdmin, out isSubAdmin, out isCustomize);
                return ARServer;
            }
            catch (ARException e)
            {
                Console.WriteLine("Unable to log into Remedy, please ensure credentials are correct.");
                logger.Error("{0} Error caught, " + e.InnerException);
                return null;
            }
        }
        #endregion
        #region Remedy Entry Creation for Dept JSON
        //Method specifically for creating with "DepartmentObject" class defined, may rework this to be more dynamic
        public void createRemedyEntry(BMC.ARSystem.Server ARServer, string formName, DepartmentObject item)
        {
            logger.Debug("Entering createRemedyEntry function");
            FieldValueList fields = new FieldValueList();
            Type type = item.GetType();
            PropertyInfo[] properties = type.GetProperties();
            fields.Add(SysStatus, "Active");
            foreach (PropertyInfo property in properties)
            {
                logger.Debug("Name: " + property.Name + ", Value: " + property.GetValue(item, null));
                string propertyValue = (string)property.GetValue(item, null);
                string remedyField = property.Name;
                if (propertyValue != null && typeof(Program).GetField(remedyField) != null)
                {
                    uint value = new uint();
                    FieldInfo reflectedValue = typeof(Program).GetField(remedyField);
                    value = (uint)reflectedValue.GetValue(null);
                    uint remedyFieldId = (uint)value;
                    fields.Add(remedyFieldId, propertyValue);
                    logger.Debug(value.ToString());
                }
                else
                {
                    logger.Debug("Propety Value for " + property.Name + " was null, will not be added to fields.");
                }
            }
            //Potential values for "effStatus" are "A" or "I" for Active/Inactive
            if (fields[effStatus].ToString() == "A")
            {
                fields.Add(SysStatus, "Active");
            }
            else
            {
                fields.Add(SysStatus, "Inactive");
            }
            //Create entry
            try
            {
                string ticketnumber = ARServer.CreateEntry(departmentalDataForm, fields);
            }
            catch (Exception err)
            {
                Console.WriteLine(err.ToString());
                logger.Debug(err.ToString());
            }
            logger.Debug("Exiting createRemedyEntry function");
        }
        #endregion
        #region Obtaining Departmental Information from PS
        /**
         * Method for obtaining the departmental information from the ITS web service provided
         **/
        private async Task obtainDeptInformation(BMC.ARSystem.Server ARServer)
        {
            Console.WriteLine("Starting obtainDeptInformation() to process the WSDL for department data (JSON)");
            //Initialize classes
            httpClient = new HttpClient();
            //In case we want to set a max buffer size, this is how you would do it. Note: 256k is nowhere near enough for the dept json
            //httpClient.MaxResponseContentBufferSize = 256000;
            //Sets what our httpclient is going to emulate
            httpClient.DefaultRequestHeaders.Add("user-agent", "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)");
            try
            {
                string responseBodyAsText;
                //logger.Debug("Waiting for response...");
                //Grab the entire JSON response
                HttpResponseMessage response = await httpClient.GetAsync("https://itsappstest.unc.edu/myaccounts/webresources/utilities/departments");
                //If the response is not "success" then this will throw an exception
                response.EnsureSuccessStatusCode();

                responseBodyAsText = await response.Content.ReadAsStringAsync();
                responseBodyAsText = responseBodyAsText.Replace("<br>", Environment.NewLine);

                JsonSerializerSettings serializerSettings = new JsonSerializerSettings();
                //serializerSettings.Converters.Add(
                Departments departments = JsonConvert.DeserializeObject<Departments>(responseBodyAsText);
                foreach (var item in departments.resultObj)
                {
                    /*
                    logger.Debug("setId: {0}, deptId: {1}, effDt: {2}, effDtStr: {3}, effStatus: {4}, descr: {5}, " +
                        "descrShort: {6}, managerName: {7}, accountingOwner: {8}, descrLong: {9},", item.setId, item.deptId, 
                        item.effDt, item.effDtStr, item.effStatus, item.descr, item.descrShort, item.managerName, item.accountingOwner, 
                        item.descrLong);
                     * */
                    createRemedyEntry(ARServer, departmentalDataForm, item);
                }
            }
            catch (HttpRequestException hre)
            {
                Console.WriteLine(hre.ToString());
                logger.Debug(hre.ToString());
            }
            Console.WriteLine("obtainDeptInformation Finish Time: " + DateTime.Now.ToString());
        }
        #endregion
        #region Obtaining Service Information from Control Center
        /**
         * Method for obtaining the the service list that the Control Center maintains, this is in XML due to the JSON not being an array
         **/
        
        private async Task obtainServiceInformation(BMC.ARSystem.Server ARServer)
        {
            logger.Debug("Starting obtainServiceInformation() to process the WSDL for service data (JSON)");
            RemedyITSServiceList serviceCheck = new RemedyITSServiceList();
            httpClient = new HttpClient();
            //Sets what our httpclient is going to emulate
            httpClient.DefaultRequestHeaders.Add("user-agent", "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)");
            try
            {
                string responseBodyAsText;
                //Grab the entire JSON response
                HttpResponseMessage response = await httpClient.GetAsync("https://status.its.unc.edu/json.php?action=get_component_2d");
                //If the response is not "success" then this will throw an exception
                response.EnsureSuccessStatusCode();
                responseBodyAsText = await response.Content.ReadAsStringAsync();
                responseBodyAsText = responseBodyAsText.Replace("<br>", Environment.NewLine);
                JsonSerializerSettings serializerSettings = new JsonSerializerSettings();
                Service[] serviceList = JsonConvert.DeserializeObject<Service[]>(responseBodyAsText);
                ArrayList serviceStringArray = new ArrayList();
                foreach(Service service in serviceList)
                {
                    /**
                     * May need to modify this section of code to allow for two scenarios:
                     * Need to check for Parent in service.parent field, then find the parent and make it read such as "Network > DNS"
                     * Need to check to see if record exists, then instead of creating a new record activate the old record
                     **/
                    //Check and see if element exists in Remedy
                    string serviceName = service.name;
                    string serviceID = service.id;
                    string parentID = service.parent;

                    serviceStringArray.Add(serviceName);
                    if (!serviceCheck.doesITSServiceExist(ARServer, serviceName))
                    {
                        //If it does not exist, we need to add it.
                        logger.Debug("Adding " + serviceName + " to Remedy");
                        serviceCheck.AddNewService(ARServer, serviceName, serviceID, parentID);
                    }
                    /* A debug to write out each parameter, in case this is needed
                    logger.Debug("id: {0}, name: {1}, parent: {2}, status: {3}, description: {4}, comment: {5}, cp: {6}, temp: {7}, temp_cp: {8}"
                        , service.id, service.name, service.parent, service.status, service.description, service.comment, service.cp, service.temp, service.temp_cp);
                     * */
                }
                //Now we need to check and make sure Remedy does not have any records that need to be "inactivated"
                //The qualification for this is ACTIVE records that are present in remedy, but NOT in the list of services
                //Get a list of all items from Remedy
                //2014_04_24 - Also going to add a check in here for parent id
                foreach (EntryFieldValue efv in serviceCheck.grabAllEntries(ARServer))
                {
                    string remedyValue = efv.FieldValues[536870913].ToString(); //Service Name
                    string parentID = efv.FieldValues[536870916].ToString(); //ParentID
                    string parentName = efv.FieldValues[536870915].ToString(); //Parent Name
                    //This section will try to find any active record in Remedy that is not present in the JSON
                    try
                    {
                        if (serviceStringArray.Contains(remedyValue))
                        {
                            logger.Debug("Value " + remedyValue + " from Remedy was contained in the JSON - no action needed.");
                        }
                        else
                        {
                            string entryid = efv.FieldValues[1].ToString();
                            logger.Debug("Value " + remedyValue + " from Remedy was not contained in the JSON - inactivating record " + entryid + ".");
                            serviceCheck.disableRecord(ARServer, entryid);
                        }
                    }
                    catch (Exception e)
                    {
                        logger.Error(e.ToString);
                    }
                    //This will check and see if there is a parent ID but not a parent service name, and will fill a service name if applicable
                    try
                    {
                        if (!String.IsNullOrEmpty(parentID) && String.IsNullOrEmpty(parentName))
                        {
                            if (parentID != "0")
                            {
                                //Do a lookup on the parentID to find the service name 
                                logger.Debug("Setting parent name...");
                                string name = serviceCheck.findServiceIDName(ARServer, parentID);
                                //Add the service name to the EFV
                                serviceCheck.setParentName(ARServer, name, efv.FieldValues[1].ToString());
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        logger.Error(e.ToString);
                    }
                }
            }
            catch (HttpRequestException hre)
            {
                Console.WriteLine(hre.ToString());
                logger.Error(hre.ToString());
            }
            logger.Debug("Finished obtainServiceInformation() to process the WSDL for service data (JSON)");
            logger.Info("obtainServiceInformation Finish Time: " + DateTime.Now.ToString());
        }
        #endregion
        #region JSON Classes
        /**
         * Need to create individual objects for the JSON calls
         **/
        public class DepartmentObject
        {
            public string setId { get; set; }
            public string deptId { get; set; }
            public string effDt { get; set; }
            public string effDtStr { get; set; }
            public string effStatus { get; set; }
            public string descr { get; set; }
            public string descrShort { get; set; }
            public string descrLong { get; set; }
            public string managerName { get; set; }
            public string accountingOwner { get; set; }
        }
        /**
         * This class contains all the individual DepartmentObjects and we can iterate through it to obtain each DepartmentObject
         **/
        public class Departments
        {
            public string result { get; set; }
            public List<DepartmentObject> resultObj { get; set; }
            public string success { get; set; }
        }
        public class Service
        {
            public string id { get; set; }
            public string name { get; set; }
            public string parent { get; set; }
            public string status { get; set; }
            public string description { get; set; }
            public string comment { get; set; }
            public string cp { get; set; }
            public string temp { get; set; }
            public string temp_cp { get; set; }
        }
        #endregion

        public class RemedyITSServiceList
        {
            private string _query;
            private EntryListFieldList _fields;
            private EntryFieldValueList _results;
            const string ITSCCServiceStatusList = "ITS-CC-Service-Status-List";
            public static int SysStatus = 536870923;
            public static int Service = 536870913;
            public static int ServiceID = 536870914;
            public static int ParentName = 536870915;
            public static int ParentID = 536870916;
            public void disableRecord(BMC.ARSystem.Server ARServer, string entryid)
            {
                FieldValueList updates = new FieldValueList();
                updates.Add((uint)SysStatus, "Inactive");
                updates.Add(1, entryid);
                ARServer.SetEntry(ITSCCServiceStatusList, entryid, updates);
            }
            public EntryFieldValueList grabAllEntries(BMC.ARSystem.Server ARServer)
            {
                _fields = new EntryListFieldList();
                _fields.AddField(SysStatus);
                _fields.AddField(ParentID);
                _fields.AddField(Service);
                _fields.AddField(ParentName);
                _fields.AddField(1);
                _query = "('" + SysStatus.ToString() + "' = 1)";
                logger.Debug("This is the _query for grabAllEntries \n" + _query.ToString());
                _results = ARServer.GetListEntryWithFields(ITSCCServiceStatusList, _query, _fields, 0, 0);
                return _results;
            }
            //In theory, there should be only ONE result from this query as the ID should be unique
            public string findServiceIDName(BMC.ARSystem.Server ARServer, string serviceID)
            {
                string serviceName = string.Empty;
                _fields = new EntryListFieldList();
                _fields.AddField(SysStatus);
                _fields.AddField(ServiceID);
                _fields.AddField(Service);
                _query = "('" + SysStatus.ToString() + "' = 1 AND '" + ServiceID.ToString() + "' = \"" + serviceID + "\")";
                logger.Debug("This is the _query for findServiceIDName \n" + _query.ToString());
                _results = ARServer.GetListEntryWithFields(ITSCCServiceStatusList, _query, _fields, 0, 0);
                if (_results.Count > 1)
                    logger.Warn("Unexpected result in findServiceIDName, multiple matches for serviceID: " + serviceID + ".");
                else
                {
                    serviceName = _results[0].FieldValues[Service].ToString();
                    logger.Debug("ServiceName lookup returned " + serviceName + " for serviceID " + serviceID + ".");
                }
                return serviceName;
            }
            public bool doesITSServiceExist(BMC.ARSystem.Server ARServer, string service)
            {
                _fields = new EntryListFieldList();
                _fields.AddField(SysStatus);
                _fields.AddField(Service);
                _query = "('" + SysStatus.ToString() + "' = 1 AND '" + Service.ToString() + "' = \"" + service + "\")";
                logger.Debug("This is the _query for RemedyITSServiceList \n" + _query.ToString());
                _results = ARServer.GetListEntryWithFields(ITSCCServiceStatusList, _query, _fields, 0, 0);
                if (_results.Count == 1)
                {
                    logger.Debug("Result was found for query");
                    return true;
                }
                else
                {
                    logger.Debug("Result was not found for query");
                    return false;
                }
            }
            public string isITSServiceInactive(BMC.ARSystem.Server ARServer, string service)
            {
                _fields = new EntryListFieldList();
                _fields.AddField(SysStatus);
                _fields.AddField(Service);
                _fields.AddField(1);
                _query = "('" + SysStatus.ToString() + "' = 0 AND '" + Service.ToString() + "' = \"" + service + "\")";
                logger.Debug("This is the query to check for an inactive record so we can activate it");
                _results = ARServer.GetListEntryWithFields(ITSCCServiceStatusList, _query, _fields, 0,0);
                if(_results.Count == 1)
                { return _results[0].FieldValues[1].ToString(); }
                else
                { return null; }
            }

            public void AddNewService(BMC.ARSystem.Server ARServer, string service, string serviceID, string parentID)
            {
                FieldValueList fields = new FieldValueList();
                fields.Add((uint)SysStatus, "Active");
                if (! String.IsNullOrEmpty(service))
                {
                    fields.Add((uint)Service, service);
                    //logger.Debug(value.ToString());
                }
                else
                {
                    logger.Warn("service was null or empty, ignoring.");
                }
                if(!String.IsNullOrEmpty(serviceID))
                {
                    fields.Add((uint)ServiceID, serviceID);
                }
                else
                {
                    logger.Warn("serviceID was null or empty, ignoring.");
                }
                if (!String.IsNullOrEmpty(parentID))
                {
                    fields.Add((uint)ParentID, parentID);
                }
                else
                {
                    logger.Warn("parentID was null or empty, ignoring.");
                }
                try
                {
                    //Check and see if service already exists, but is inactive
                    string updateTicket = isITSServiceInactive(ARServer, service);
                    if (!String.IsNullOrEmpty(updateTicket))
                    {
                        ARServer.SetEntry(ITSCCServiceStatusList, updateTicket, fields);
                        logger.Debug("Entry " + updateTicket + " was successfully updated for record");
                    }
                    else
                    {
                        string ticketnumber = ARServer.CreateEntry(ITSCCServiceStatusList, fields);
                        logger.Debug("Entry " + ticketnumber + " was successfully created for record");
                    }
                }
                catch (Exception err)
                {
                    Console.WriteLine(err.ToString());
                    logger.Error(err.ToString());
                }
            }
            public void setParentName(BMC.ARSystem.Server ARServer, string parentName, string entryID)
            {
                FieldValueList fields = new FieldValueList();
                try
                {
                    fields.Add((uint)ParentName, ParentName);
                    if (!String.IsNullOrEmpty(entryID))
                    {
                        ARServer.SetEntry(ITSCCServiceStatusList, entryID, fields);
                        logger.Debug("Entry " + entryID + " had parent " + parentName + " added successfully");
                    }
                }
                catch (Exception e)
                {
                    logger.Error(e.ToString());
                }
            }
        }
        #region Not Being Used / Deprecated / Non Functional
        #region Keith's JSON (no array)
        //For Consuming Keith's JSON that does not have arrays...
        /*
        public class ControlCenter_ServiceObject
        {
            public string name { get; set; }
            public string parent { get; set; }
            public string status { get; set; }
            public string description { get; set; }
            public string comment { get; set; }
            public string cp { get; set; }
            public string temp { get; set; }
            public string temp_cp { get; set; }
        }
        public class Base
        {
            public string name { get; set; }
            public string parent { get; set; }
            public string status { get; set; }
            public string description { get; set; }
            public string comment { get; set; }
            public string cp { get; set; }
            public string temp { get; set; }
            public string temp_cp { get; set; }
        }
        public class Objects
        {
            public List<Base> bases { get; set; }

            public Objects()
            {
                bases = new List<Base>();
            }
        }
        public class ObjectContainer
        {
            public int count { get; set; }
            public Objects objects { get; set; }

            public ObjectContainer()
            {
                objects = new Objects();
            }
        }
        public class RootObject
        {
            public ObjectContainer objectContainer { get; set; }

            public RootObject()
            {
                objectContainer = new ObjectContainer();
            }
        }
         * */
        #endregion
        //Methods that are not functioning that were used to test Keith's JSON data
        /*
        public void createRemedyEntry(BMC.ARSystem.Server ARServer, string formName, DepartmentObject item)
        {
            FieldValueList fields = new FieldValueList();
            Type type = item.GetType();
            PropertyInfo[] properties = type.GetProperties();
            fields.Add(SysStatus, "Active");
            foreach (PropertyInfo property in properties)
            {
                //logger.Debug("Name: " + property.Name + ", Value: " + property.GetValue(item, null));
                string propertyValue = (string)property.GetValue(item, null);
                string remedyField = property.Name;
                if (propertyValue != null && typeof(Program).GetField(remedyField) != null)
                {
                    uint value = new uint();
                    FieldInfo reflectedValue = typeof(Program).GetField(remedyField);
                    value = (uint)reflectedValue.GetValue(null);
                    uint remedyFieldId = (uint)value;
                    fields.Add(remedyFieldId, propertyValue);
                    //logger.Debug(value.ToString());
                }
                else
                {
                    logger.Debug("Propety Value for " + property.Name + " was null, will not be added to fields.");
                }
            }
            try
            {
                string ticketnumber = ARServer.CreateEntry(departmentalDataForm, fields);
            }
            catch (Exception err)
            {
                Console.WriteLine(err.ToString());
                logger.Debug(err.ToString());
            }
        }
        private async void obtainServiceInformation(BMC.ARSystem.Server ARServer)
        {
            httpClient = new HttpClient();
            //In case we want to set a max buffer size, this is how you would do it. Note: 256k is nowhere near enough for the dept json
            //httpClient.MaxResponseContentBufferSize = 256000;
            //Sets what our httpclient is going to emulate
            httpClient.DefaultRequestHeaders.Add("user-agent", "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)");
            try
            {

                string responseBodyAsText;
                //logger.Debug("Waiting for response...");
                //Grab the entire JSON response
                HttpResponseMessage response = await httpClient.GetAsync("http://status.its.unc.edu/json.php?action=get_component");
                //If the response is not "success" then this will throw an exception
                response.EnsureSuccessStatusCode();

                responseBodyAsText = await response.Content.ReadAsStringAsync();
                //responseBodyAsText = responseBodyAsText.Replace("<br>", Environment.NewLine);
                JsonSerializerSettings serializerSettings = new JsonSerializerSettings();
                StringReader stringReader = new StringReader(responseBodyAsText);
                JsonTextReader reader = new JsonTextReader( stringReader );
                RootObject root = new RootObject();
                Base newBase = new Base();
                while (reader.Read())
                {
                    if (reader.Value != null)
                    {
                        switch (reader.Depth)
                        {
                            case 2:
                                if (reader.TokenType == JsonToken.PropertyName && reader.Value.ToString() == "count")
                                {
                                    reader.Read();
                                    root.objectContainer.count = Convert.ToInt32(reader.Value);
                                }
                                break;

                            case 3:
                                newBase = new Base();
                                root.objectContainer.objects.bases.Add(newBase);
                                break;

                            case 4:
                                if (reader.TokenType == JsonToken.PropertyName && reader.Value.ToString() == "name")
                                {
                                    logger.Debug("Inside a name property");
                                    reader.Read();
                                    newBase.name = reader.Value.ToString();
                                }
                                if (reader.TokenType == JsonToken.PropertyName && reader.Value.ToString() == "parent")
                                {
                                    reader.Read();
                                    newBase.parent = reader.Value.ToString();
                                }
                                if (reader.TokenType == JsonToken.PropertyName && reader.Value.ToString() == "status")
                                {
                                    reader.Read();
                                    newBase.status = reader.Value.ToString();
                                }
                                break;
                        }
                    }
                }
            }
            catch (HttpRequestException hre)
            {
                Console.WriteLine(hre.ToString());
                logger.Debug(hre.ToString());
            }
            Console.WriteLine("End Time: " + DateTime.Now.ToString());   
        }

        private async void ReadDataFromWeb()
        {
            var client = new HttpClient(); // Add: using System.Net.Http;
            var response = await client.GetAsync(new Uri("http://status.its.unc.edu/json.php?action=get_component"));
            var result = await response.Content.ReadAsStringAsync();

            StringReader stringReader = new StringReader(result);
            JsonTextReader reader = new JsonTextReader(stringReader);
            RootObject root = new RootObject();
            Base newBase = new Base();
            while (reader.Read())
            {
                if (reader.Value != null)
                {
                    switch (reader.Depth)
                    {
                        case 2:
                            if (reader.TokenType == JsonToken.PropertyName && reader.Value.ToString() == "count")
                            {
                                reader.Read();
                                root.objectContainer.count = Convert.ToInt32(reader.Value);
                            }
                            break;

                        case 3:
                            newBase = new Base();
                            root.objectContainer.objects.bases.Add(newBase);
                            break;

                        case 4:
                            if (reader.TokenType == JsonToken.PropertyName && reader.Value.ToString() == "name")
                            {
                                logger.Debug("Inside a name property");
                                reader.Read();
                                newBase.name = reader.Value.ToString();
                            }
                            if (reader.TokenType == JsonToken.PropertyName && reader.Value.ToString() == "parent")
                            {
                                reader.Read();
                                newBase.parent = reader.Value.ToString();
                            }
                            if (reader.TokenType == JsonToken.PropertyName && reader.Value.ToString() == "status")
                            {
                                reader.Read();
                                newBase.status = reader.Value.ToString();
                            }
                            break;
                    }
                }
            }

            // Display data read from web site
            logger.Debug(result);
        }
         * */
        /*
        private async void ReadXML(BMC.ARSystem.Server ARServer)
        {
            RemedyITSServiceList serviceCheck = new RemedyITSServiceList();
            Console.WriteLine("Starting ReadXML() to process the Control Center's Service List");
            var client = new HttpClient();
            var response = await client.GetAsync(new Uri("http://status.its.unc.edu/xml_servicelist.php"));
            var stream = await response.Content.ReadAsStreamAsync();
            var xmlDocument = new XmlDocument();
            //Create a new XML Document out of the response from the website
            xmlDocument.Load(stream);
            //Get the name of each service, they all have a tag of "value"
            XmlNodeList elemList = xmlDocument.GetElementsByTagName("value");
            //Iterate through our list and pull out the text
            //i=0 is a composite of each element, so we skip that one for this purpose
            for (int i = 1; i < elemList.Count; i++)
            {
                logger.Debug(elemList[i].InnerText);
                //Check and see if element exists in Remedy

                if (!serviceCheck.doesITSServiceExist(ARServer, elemList[i].InnerText))
                {
                    //If it does not exist, we need to add it.
                    logger.Debug("Adding " + elemList[i].InnerText + " to Remedy");
                    serviceCheck.AddNewService(ARServer, elemList[i].InnerText);
                }
            }

            //Now we need to check and make sure Remedy does not have any records that need to be "inactivated"
            //The qualification for this is records that are present in remedy, but NOT in the list of services
            //Get a list of all items from Remedy

            foreach (EntryFieldValue efv in serviceCheck.grabAllEntries(ARServer))
            {
                string remedyValue = efv.FieldValues[536870913].ToString();
                //Here we use i=0, because it contains all values
                if (elemList[0].InnerText.Contains(remedyValue))
                {
                    logger.Debug("Value " + remedyValue + " from Remedy was contained in the XML - no action needed.");
                }
                else
                {
                    string entryid = efv.FieldValues[1].ToString();
                    logger.Debug("Value " + remedyValue + " from Remedy was not contained in the XML - inactivating record " + entryid + ".");
                    serviceCheck.disableRecord(ARServer, entryid);
                }

            }

            Console.WriteLine("ReadXML Finish Time: " + DateTime.Now.ToString());
        }
         * */
        #endregion
    }
}
