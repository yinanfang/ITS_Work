﻿using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Email_In_Client
{
    class Program
    {
        // NLog
        private static Logger logger = LogManager.GetCurrentClassLogger();
        private static string log_msg;

        static void Main(string[] args)
        {
            // Console settings
            Console.BufferHeight = Int16.MaxValue - 1;
            Console.BufferWidth = 150;
            Console.SetWindowSize(150, 80);

            // Start message
            string startTime = DateTime.Now.ToString("yyyy-M-d_hh-mm-ss");
            Console.WriteLine("========================================  Email-In Client Started at {0}  ========================================", startTime);
            logger.Info("");
            logger.Info("================================================================================================================================================================");
            logger.Info("Email-In Client Started at " + startTime);

            // Main Process
            EmailProcess process = new EmailProcess();
            process.startProcessingEmails();

            // End message
            string endTime = DateTime.Now.ToString("yyyy-M-d_hh-mm-ss");
            Console.WriteLine("========================================   Email-In Client Ended at {0}   ========================================", endTime);
            logger.Info("Email-In Client Ended at " + endTime);
            logger.Info("================================================================================================================================================================");

            // Check
            Console.WriteLine("(Press any key to continue...)");
            Console.ReadKey(true);
        }
    }
}
