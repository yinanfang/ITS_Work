﻿using Microsoft.Exchange.WebServices.Data;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Email_In_Client
{
	class Remedy_Service
	{
		// Remedy properties
		public static BMC.ARSystem.Server ARServer;
		private static string form_RFS = "UNC-Request for Service";

		// EWS properties
		public static string email_withActiveEntry;

		// NLog
		private static Logger logger = LogManager.GetCurrentClassLogger();
		private static string log_msg;

		// Empty constructor
		public Remedy_Service(){}

		public bool initRemedyService()
		{
			// Remedy
			try
			{
				Console.WriteLine("\r\nStart Remedy connection...");
				ARServer = new BMC.ARSystem.Server();
				string username = System.Configuration.ConfigurationManager.AppSettings["RemedyUsername"];
				string password = System.Configuration.ConfigurationManager.AppSettings["RemedyPassword"];
				string server = System.Configuration.ConfigurationManager.AppSettings["RemedyServer"];
				ARServer.Login(server, username, password);
				ARServer.SetSessionConfiguration(9, 1);
				bool isAdmin, isSubAdmin, isCustomize;
				ARServer.VerifyUser(out isAdmin, out isSubAdmin, out isCustomize);
				Console.WriteLine("Init Remedy successfully...");
				return true;
			}
			catch (Exception ex)
			{
				string err_msg = "Unable to connect to Remedy... \nError: " + ex.Message + "\nException type: " + ex.GetType().FullName;
				Console.WriteLine(err_msg);
				logger.Fatal(err_msg);
				return false;
			}
		}

		public bool isValidTicketNumber(string ticketNumber_str)
		{
			getRFSInfo getTicket = new getRFSInfo(ARServer, ticketNumber_str, form_RFS);
			if (getTicket.getEverything.Count > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		public bool hasActiveEntry(EmailMessage message)
		{
			List<string> toAndCCAddresses = new List<string>();
			for (int i = 0; i < message.ToRecipients.Count; i++)
			{
				toAndCCAddresses.Add(message.ToRecipients[i].Address);
			}
			for (int i = 0; i < message.CcRecipients.Count; i++)
			{
				toAndCCAddresses.Add(message.CcRecipients[i].Address);
			}
			Console.WriteLine("Recipients count: {0}; including TO and CC: {1}", toAndCCAddresses.Count.ToString(), String.Join(", ", toAndCCAddresses.ToArray()));
			for (int i = 0; i < toAndCCAddresses.Count; i++)
			{
                string emailAddress = toAndCCAddresses[i];
                emailAddress = emailAddress.Replace(" ", "");
                emailAddress = emailAddress.Replace("'", "");
                emailAddress = emailAddress.Replace("\"", "");
				UNCRSEmailIn EmailInEntry = new UNCRSEmailIn(ARServer, emailAddress);
				if (EmailInEntry.getEverything.Count > 0)
				{
					email_withActiveEntry = toAndCCAddresses[i];
					Console.WriteLine("Found Active entry with address: " + toAndCCAddresses[i]);
					return true;
				}

			}
			return false;
		}

	}
}
