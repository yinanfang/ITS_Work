﻿using Microsoft.Exchange.WebServices.Data;
using NLog;
using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Email_In_Client
{
    class EWS_Service
    {
        // EWS properties
        private static ExchangeService EWSService;
        private static Folder rootFolder;
        private static Folder processedFolder;
        private static Folder notProcessedFolder;
        // NLog
        private static Logger logger = LogManager.GetCurrentClassLogger();
        private static string log_msg;

        // Empty constructor
        public EWS_Service(){}

        public bool initEWSService()
        {
            // EWS
            try
            {
                Console.WriteLine("\r\nStart EWS connection...");
                EWSService = new ExchangeService(ExchangeVersion.Exchange2010_SP2);
                string username = System.Configuration.ConfigurationManager.AppSettings["EWSUsername"];
                string password = System.Configuration.ConfigurationManager.AppSettings["EWSPassword"];
                string autodiscoverUrl = System.Configuration.ConfigurationManager.AppSettings["EWSAutodiscoverUrlServer"];
                EWSService.Credentials = new WebCredentials(username, password);
                EWSService.AutodiscoverUrl(autodiscoverUrl);

                // Init folders
                rootFolder = Folder.Bind(EWSService, WellKnownFolderName.MsgFolderRoot);
                rootFolder.Load();
                foreach (Folder folder in rootFolder.FindFolders(new FolderView(100)))
                {
                    if (folder.DisplayName == "Processed")
                    {
                        processedFolder = folder;
                    }
                    if (folder.DisplayName == "Not-Processed")
                    {
                        notProcessedFolder = folder;
                    }
                }


                Console.WriteLine("Init EWS successfully...");
                return true;
            }
            catch (Exception ex)
            {
                string err_msg = "Unable to connect to EWS... \nError: " + ex.Message + "\nException type: " + ex.GetType().FullName;
                Console.WriteLine(err_msg);
                logger.Fatal(err_msg);
                return false;
            }
        }

        public FindItemsResults<Item> getUnreadItems()
        {
            // Access unread emails
            Folder inBox = Folder.Bind(EWSService, WellKnownFolderName.Inbox);
            // Look at unread?
            SearchFilter searchFilter = new SearchFilter.SearchFilterCollection(LogicalOperator.And, new SearchFilter.IsEqualTo(EmailMessageSchema.IsRead, false));
            ItemView view = new ItemView(10000);
            // Query unread items
            FindItemsResults<Item> findResults = EWSService.FindItems(WellKnownFolderName.Inbox, searchFilter, view);
            return findResults;
        }

        public bool isSystemEmail(string email)
        {
            // Check if the email come from system
            Match match01 = Regex.Match(email, @"^arsys@.+$", RegexOptions.IgnoreCase);
            Match match02 = Regex.Match(email, @"^noreply@email.unc.edu.*$", RegexOptions.IgnoreCase);
            if (match01.Success || match02.Success)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool hasTicketNumber(string subject)
        {
            String standardSubject = @"\b(ticket [0-9]{7})\b";
            Match match = Regex.Match(subject, standardSubject, RegexOptions.IgnoreCase);
            if (match.Success)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void moveMessageToProcessed(EmailMessage message)
        {
            // Move to "Processed"
            message.Move(processedFolder.Id);
            Console.WriteLine("Moved ticket to Processed folder...");

        }

        public void moveMessageToNotProcessed(EmailMessage message)
        {
            // Move to "Not-Processed"
            message.Move(notProcessedFolder.Id);
            Console.WriteLine("Moved ticket to Not-Processed folder...");
        }

        public string loopUpOnyen(string email)
        {
            SearchResult result = null;
            string filter = string.Format("(proxyaddresses=SMTP:{0})", email);
            using (DirectoryEntry gc = new DirectoryEntry("GC:"))
            {
                foreach (DirectoryEntry z in gc.Children)
                {
                    using (DirectoryEntry root = z)
                    {
                        using (DirectorySearcher searcher = new DirectorySearcher(root, filter, new string[] { "proxyAddresses", "objectGuid", "displayName", "distinguishedName", "uid" }))
                        {
                            searcher.ReferralChasing = ReferralChasingOption.All;
                            SearchResult newResult = searcher.FindOne();
                            result = newResult;
                        }
                    }
                }
            }

            try
            {
                string onyen = result.Properties["uid"][0] as string;
                return onyen;
            }
            catch (Exception)
            {

            }
            return email;
        }

        public string getOriginalSender(EmailMessage message)
        {
            //RemedyTicket ticket = new RemedyTicket();
            //string ticket_body = ticket.getCleanMessageBody(message);
            //Console.WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>Current tickey body");
            //Console.WriteLine(ticket_body);
            //Console.WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");


            return (message.Sender.Address == null) ? "No@Address" : message.Sender.Address;
        }

    }
}
