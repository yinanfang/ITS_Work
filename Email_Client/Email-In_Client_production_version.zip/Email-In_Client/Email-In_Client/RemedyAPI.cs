﻿using System;
using Microsoft.Exchange.WebServices.Data;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using NLog;
using BMC.ARSystem;

namespace Email_In_Client
{
    public class RemedyAPI
    {
    }

    public class UNCOrgGroups
    {
        public const int ORG_GRP_INTEGER = 536870925;
        public const int STATUS = 7;
        public const int GRP_ADDR = 536870924;//GROUP LISTSERV
        public const int ALIAS = 536870969;
        public const int ORG_GRP = 536870953;//ORG GROUP DESCRIPTION/NAME


        private String _query;
        private EntryListFieldList _fields;
        private EntryFieldValueList _results;

        /**************************************************************
        Constructor #1: User passes  Campus values as a string for query
        **************************************************************/
        public UNCOrgGroups(BMC.ARSystem.Server ARServer, int orggroupInt)
        {
            /* Add fields to list to be retrieved by query*/
            _fields = new EntryListFieldList();
            _fields.AddField(GRP_ADDR, 255, "");  // GROUP LISTSERV
            _fields.AddField(ORG_GRP, 255, ""); // GROUP DESC


            _query = "'" + ORG_GRP_INTEGER.ToString() + "' = " + orggroupInt + " AND '" + STATUS.ToString() + "' = 0"; // Query for the Remedy Form: for that particular Remedy Group
            _results = ARServer.GetListEntryWithFields("UNC-OrgGroups", _query, _fields, 0, 0); // Actually Query The Form
        }
        /*************************************************************************
     GetSearchResults: Return all results as an EntryFieldValueList
     **************************************************************************/
        public EntryFieldValueList GetSearchResults
        {
            get
            {
                return _results;
            }
        }

        public String GetGroupAddress
        {
            get
            {
                if (_results[0].FieldValues[GRP_ADDR] != null)
                {
                    return _results[0].FieldValues[GRP_ADDR].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }

    }



    public class RfsFields
    {
        public const string FORM_NAME = "UNC-Request for Service";

        public const int TICKET_NUMBER = 536870988;
        public const int CLIENTS_PROBLEM_DESCRIPTION = 536870955;
        public const int GROUP_ASSIGNED = 536870929;
        public const int PERSON_ASSIGNED = 536870931;
        public const int CUSTOMER_FIRST_NAME = 536870926;
        public const int CUSTOMER_LAST_NAME = 536870918;
        public const int CUSTOMER_MIDDLE_INITIAL = 536870966;
        public const int CUSTOMER_AFFILIATION = 536870969;
        public const int CUSTOMER_DEPARTMENT = 536870963;
        public const int CUSTOMER_TELEPHONE = 536870936;
        public const int CUSTOMER_LOCATION = 536870948;
        public const int CUSTOMER_EMAIL = 536870950;
        public const int CUSTOMER_ONYEN = 536871172;
        public const int CUSTOMER_PID = 536870917;
        public const int SEVERITY = 536871069;
        public const int STATUS = 536871035;
        public const int CREATE_DATE = 3;
        public const int MODIFIED_DATE = 6;
        public const int MODIFIED_BY_PERSON = 5;
        public const int MODIFIED_BY_GROUP = 536871067;
        public const int SHORT_DESCRIPTION = 536870937;
        public const int CATEGORY = 536871242;
        public const int TOPIC_AFFECTED = 536870939;
        public const int ITEM_AFFECTED = 536870932;
        public const int WORKLOG = 536870923;
        public const int WORKLOG_IN = 536870923;
        public const int SYS_PERL_SCRIPT_CREATED = 536871241;
        public const int SOURCE = 536870924;
        public const int EMAIL_NOTIFY = 536871101;
        public const int PROBLEM_LOCALE = 536871240;
        public const string STATUS_STRING = "536871035";
        public const int GROUP_CREATED = 536871036;

        public const uint CSIT_BUILDINGLIST = 536870913;
        public const uint UNC_BLDG = 536871240;

        // below are translated from ITS RemedyMobile
        public const uint CREATOR = 2;
        public const uint SYS_ORGGROUP_ID = 536870954;
        public const uint EMAILTO = 536871022;
        public const uint EMAILCC = 536870942;
        public const uint EMAILTEXT = 536871021;
        public const uint EMAILWORKLOG = 536871056;
        public const uint EMAILREPLYTO = 536870941;
        public const uint SYS_EMAIL_FLAG = 536870930;
        public const uint POINT_OF_CONTACT = 536870924;
        public const uint CUSTOMER_POINT_OF_CONTACT = 536870924;
        public const uint SYS_ACK = 536870978;
        public const uint EMAIL_UPDATES = 536871101; //Sys-Send Client WLUPDATE
        public const uint FOLLOW_UP_EMAIL = 536871083;
        public const uint IP_ADDRESS = 536871102;
        public const uint MODIFIED = 536871311;
        public const int SYS_TEMPLATE = 536871191;
        public const int SYS_EMAIL_IN_SENDEMAIL = 536871228;
        public const int SYS_INT_REQUEST_NUMBER = 536870988;
        public const int SYS_CREATORORGROUPID = 536870952;

        private String _query;
        private EntryListFieldList _fields;
        private EntryFieldValueList _results;

        //Web Submit-specific fields

        public const int WEBSUBPRIMARY = 536923367;//primary category from web submit
        public const int WEBSUBSECONDARY = 536923368;//secondary category from web submit
        public const int WEBSUBTERTIARY = 536923369;//tertiary category from web submit
        public const int WEBSUBVERSION = 536923370;//field that holds the version of web submit
        public const int WEBSUBSUBMITTER = 536923371;//person that submitted request on behalf of customer
        public const int WEBSUBATTACHMENT = 536923373;//flag that will be set by web submit if an attachment was accepted 

        //Attachment Fields
        public const int ATTACHMENT_1 = 536908983;
        public const int ATTACHMENT_2 = 536908984;
        public const int ATTACHMENT_3 = 536908985;
        public const int ATTACHMENT_4 = 536908986;
        public const int ATTACHMENT_5 = 536908987;

        public RfsFields()
        {
            //
            // TODO: Add constructor logic here
            //
        }
    }

    public class UNC_WebSubmit_SearchTerms
    {

        public const string FORM_NAME = "UNC-WebSubmit-SearchTerms";

        public const int REQUEST_ID = 1;
        public const int SUBMITTER = 2;
        public const int CREATE_DATE = 3;
        public const int ASSIGNED_TO = 4;
        public const int LAST_MOD_BY = 5;
        public const int MODIFIED_DATE = 6;
        public const int STATUS = 7;
        public const int SEARCH_TERM = 8;//TERMS THEY USED ON SEARCH
        public const int STATUS_HISTORY = 15;
        public const int CUSTOMER_DEPT = 536870913;
        public const int CUSTOMER_ONYEN = 536870914;
        public const int CUSTOMER_FIRST_NAME = 536870915;
        public const int CUSTOMER_LAST_NAME = 536870916;
        public const int CUSTOMER_TYPE = 536870917;//FAC STAF ETC
        private String _query;
        private EntryListFieldList _fields;
        private EntryFieldValueList _results;
    }

    public class UNC_Contacts
    {
        public const int TICKET_NUMBER = 536870988;
        public const int CLIENTS_PROBLEM_DESCRIPTION = 536870955;
        public const int GROUP_ASSIGNED = 536870929;
        public const int PERSON_ASSIGNED = 536870931;
        public const int CUSTOMER_FIRST_NAME = 536870926;
        public const int CUSTOMER_LAST_NAME = 536870918;
        public const int CUSTOMER_MIDDLE_INITIAL = 536870966;
        public const int CUSTOMER_AFFILIATION = 536870969;
        public const int CUSTOMER_DEPARTMENT = 536870963;
        public const int CUSTOMER_TELEPHONE = 536870936;
        public const int CUSTOMER_LOCATION = 536870948;
        public const int CUSTOMER_EMAIL = 536870950;
        public const int CUSTOMER_ONYEN = 536871172;
        public const int CUSTOMER_PID = 536870917;
        public const int SEVERITY = 536871069;
        public const int STATUS = 536871035;
        public const int CREATE_DATE = 3;
        public const int MODIFIED_DATE = 6;
        public const int MODIFIED_BY_PERSON = 5;
        public const int MODIFIED_BY_GROUP = 536871067;
        public const int SHORT_DESCRIPTION = 536870937;
        public const int CATEGORY = 536871242;
        public const int TOPIC_AFFECTED = 536870939;
        public const int ITEM_AFFECTED = 536870932;
        public const int WORKLOG = 536870923;
        public const int WORKLOG_IN = 536870923;
        public const int SYS_PERL_SCRIPT_CREATED = 536871241;
        public const int SOURCE = 536870924;
        public const int EMAIL_NOTIFY = 536871101;


        public UNC_Contacts()
        {
            //
            // TODO: Add constructor logic here
            //
        }
    }
    /// <summary>
    /// Class Definition for the Remedy Form "Remedy Directory LDAP".  This form holds UNC Directory Data that is populated
    /// each evening from the Campus LDAP table.  Use this class for retrieving customer information.
    /// </summary>
    public class RemedyDirectoryLDAP
    {
        private String _query;  // The query used to retrieve the form data from Remedy
        private EntryListFieldList _fields; // A list of fields to be included in the results
        private EntryFieldValueList _results; // All of the entries and fields returned by the query
        private string whatdir = "";

        /**************************************************************
         Canonical field Names and thier respective Remedy Field IDs
         **************************************************************/
        public const int PID = 536870923;
        public const int UID = 536870926;
        public const int FIRST_NAME = 536870913;
        public const int LAST_NAME = 536870914;
        public const int MI = 536870915;
        public const int DEPARTMENT = 536870917;
        public const int EMAIL = 536870920;
        public const int PHONE_NUMBER = 536870918;
        public const int LOCATION = 536870916;
        public const int AFFILIATION = 536870924;
        public const int TYPE = 536870922;
        public const int ISPUBLIC = 536870958;


        /**************************************************************
        Constructor #1: User passes PID for query
        **************************************************************/
        public RemedyDirectoryLDAP(BMC.ARSystem.Server ARServer, string pid, int directory)
        {
            /* Add fields to list to be retrieved by query*/
            _fields = new EntryListFieldList();
            _fields.AddField(PID, 50, "");
            _fields.AddField(UID, 50, "");
            _fields.AddField(FIRST_NAME, 50, "");
            _fields.AddField(LAST_NAME, 50, "");
            _fields.AddField(MI, 50, "");
            _fields.AddField(DEPARTMENT, 50, "");
            _fields.AddField(EMAIL, 50, "");
            _fields.AddField(PHONE_NUMBER, 50, "");
            _fields.AddField(LOCATION, 50, "");
            _fields.AddField(AFFILIATION, 50, "");
            _fields.AddField(TYPE, 50, "");


            //Check what directory to search in
            if (directory == 0)
            { whatdir = "Remedy Directory LDAP"; }
            else if (directory == 1)
            { whatdir = "Remedy Directory LDAP FSU"; }

            _query = "'" + PID.ToString() + "' = \"" + pid + "\"";  // Query for the Remedy Form: 'Field Number(UID)' = "Onyen"
            _results = ARServer.GetListEntryWithFields(whatdir, _query, _fields, 0, 0);  // Actually Query the Form 
        }

        /*************************************************************************
        Constructor #2: User passes First Name, Last Name or combination for query
        **************************************************************************/
        public RemedyDirectoryLDAP(BMC.ARSystem.Server ARServer, string firstName, string lastName)
        {
            /* Add fields to list to be retrieved by query*/
            _fields = new EntryListFieldList();
            _fields.AddField(PID, 50, "");
            _fields.AddField(UID, 50, "");
            _fields.AddField(FIRST_NAME, 50, "");
            _fields.AddField(LAST_NAME, 50, "");
            _fields.AddField(MI, 50, "");
            _fields.AddField(DEPARTMENT, 50, "");
            _fields.AddField(EMAIL, 50, "");
            _fields.AddField(PHONE_NUMBER, 50, "");
            _fields.AddField(LOCATION, 50, "");
            _fields.AddField(AFFILIATION, 50, "");
            _fields.AddField(TYPE, 50, "");

            /* Determine whether First Name, Last Name or both have been provided, and build query accordingly */
            if (firstName != null && lastName == null)
            {
                _query = "'" + FIRST_NAME.ToString() + "' LIKE \"" + firstName + "%\""; // First Name Only Query
            }
            if (firstName == null && lastName != null)
            {
                _query = "'" + LAST_NAME.ToString() + "' LIKE \"" + lastName + "%\""; // Last Name Only Query
            }
            if (firstName != null && lastName != null)
            {
                _query = "'" + FIRST_NAME.ToString() + "' LIKE \"" + firstName + "%\" AND '" + LAST_NAME.ToString() + "' LIKE \"" + lastName + "%\""; // First and Last Name Query
            }

            _results = ARServer.GetListEntryWithFields("Remedy Directory LDAP", _query, _fields, 0, 0); // Actually Query the Form 
        }
        /*************************************************************************
    Constructor #3: User passes onyen OR pid for query
    **************************************************************************/
        public RemedyDirectoryLDAP(BMC.ARSystem.Server ARServer, string Onyen)
        {
            /* Add fields to list to be retrieved by query*/
            _fields = new EntryListFieldList();
            _fields.AddField(PID, 50, "");
            _fields.AddField(UID, 50, "");
            _fields.AddField(FIRST_NAME, 50, "");
            _fields.AddField(LAST_NAME, 50, "");
            _fields.AddField(MI, 50, "");
            _fields.AddField(DEPARTMENT, 50, "");
            _fields.AddField(EMAIL, 50, "");
            _fields.AddField(PHONE_NUMBER, 50, "");
            _fields.AddField(LOCATION, 50, "");
            _fields.AddField(AFFILIATION, 50, "");
            _fields.AddField(TYPE, 50, "");
            _fields.AddField(ISPUBLIC, 50, "");


            if (Onyen != null)
            {
                _query = "'" + UID.ToString() + "' = \"" + Onyen + "\"" + "OR" + "'" + PID.ToString() + "' = \"" + Onyen + "\""; // onyen OR PID Query
            }


            _results = ARServer.GetListEntryWithFields("Remedy Directory LDAP", _query, _fields, 0, 0); // Actually Query the Form 
        }

        /*************************************************************************
        GetSearchResults: Return all results as an EntryFieldValueList
        **************************************************************************/
        public EntryFieldValueList GetSearchResults
        {
            get
            {
                return _results;
            }
        }
        /*************************************************************************
        GetisPublic: Return PrivacyFlag as String
        **************************************************************************/
        public String GetIsPublic
        {
            get
            {
                if (_results[0].FieldValues[ISPUBLIC] != null)
                {
                    return _results[0].FieldValues[ISPUBLIC].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        /*************************************************************************
        GetPID: Return PID as String
        **************************************************************************/
        public String GetPID
        {
            get
            {
                if (_results[0].FieldValues[PID] != null)
                {
                    return _results[0].FieldValues[PID].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }

        /*************************************************************************
         GetAffiliation: Return Affiliation as String
         **************************************************************************/
        public String GetAffiliation
        {
            get
            {
                if (_results[0].FieldValues[AFFILIATION] != null)
                {
                    return _results[0].FieldValues[AFFILIATION].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }

        /*************************************************************************
        GetFirstName: Return FirstName as String
        **************************************************************************/
        public String GetFirstName
        {
            get
            {
                if (_results[0].FieldValues[FIRST_NAME] != null)
                {
                    return _results[0].FieldValues[FIRST_NAME].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }

        /*************************************************************************
        GetOnyen: Return Onyen as String
        **************************************************************************/
        public String GetOnyen
        {
            get
            {
                if (_results[0].FieldValues[UID] != null)
                {
                    return _results[0].FieldValues[UID].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }

        /*************************************************************************
        GetLastName: Return LastName as String
        **************************************************************************/
        public String GetLastName
        {
            get
            {
                if (_results[0].FieldValues[LAST_NAME] != null)
                {
                    return _results[0].FieldValues[LAST_NAME].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }

        /*************************************************************************
        GetMI: Return MI as String
        **************************************************************************/
        public String GetMI
        {
            get
            {
                if (_results[0].FieldValues[MI] != null)
                {
                    return _results[0].FieldValues[MI].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }

        /*************************************************************************
        GetDepartment: Return Department as String
        **************************************************************************/
        public String GetDepartment
        {
            get
            {
                if (_results[0].FieldValues[DEPARTMENT] != null)
                {
                    return _results[0].FieldValues[DEPARTMENT].ToString().Split(',')[0];
                    // return _results[0].FieldValues[DEPARTMENT].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }

        /*************************************************************************
        GetEmail: Return Email as String
        **************************************************************************/
        public String GetEmail
        {
            get
            {
                if (_results[0].FieldValues[EMAIL] != null)
                {
                    return _results[0].FieldValues[EMAIL].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }

        /*************************************************************************
        GetPhoneNumber: Return PhoneNumber as String
        **************************************************************************/
        public String GetPhoneNumber
        {
            get
            {
                if (_results[0].FieldValues[PHONE_NUMBER] != null)
                {
                    return _results[0].FieldValues[PHONE_NUMBER].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }

        /*************************************************************************
        GetLocation: Return Location as String
        **************************************************************************/
        public String GetLocation
        {
            get
            {
                if (_results[0].FieldValues[LOCATION] != null)
                {
                    return _results[0].FieldValues[LOCATION].ToString().Replace("$", "");
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        /*************************************************************************
       GetType: Return Typ[e as String
       **************************************************************************/
        public String GetType1
        {
            get
            {
                if (_results[0].FieldValues[TYPE] != null)
                {
                    return _results[0].FieldValues[TYPE].ToString().Replace("$", "");
                }
                else
                {
                    return "Unknown";
                }
            }
        }
    }
    //Gets the Group ID after receiving server and group name
    public class OrgGroupNamesAndID
    {
        public const int GROUP_NAME = 536870925;
        public const int GROUP_ID = 536870939;
        public const int STATUS = 7;
        private String _query;
        private EntryListFieldList _fields;
        private EntryFieldValueList _results, _allGroups;

        //create a constructor with server and group name
        public OrgGroupNamesAndID(BMC.ARSystem.Server ARServer, string OrgGroupName)
        {
            _fields = new EntryListFieldList();
            _fields.AddField(GROUP_NAME, 50, "");
            _fields.AddField(GROUP_ID, 50, "");

            _query = "'" + GROUP_NAME.ToString() + "' = \"" + OrgGroupName + "\" AND '" + STATUS.ToString() + "' = 0";
            _results = ARServer.GetListEntryWithFields("UNC-Contacts", _query, _fields, 0, 0);

        }

        public String GetPrimaryGroupID
        {
            get
            {
                if (_results[0].FieldValues[GROUP_ID] != null)
                {
                    return _results[0].FieldValues[GROUP_ID].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
    }

    /// <summary>
    /// Class Definition 1 for the Remedy Form "Contacts".  This form holds User Data and is used for two classes included in this library
    /// Use this class for retrieving a user's OrgGroup information.
    /// </summary>
    public class UNCContactsOrgGroup
    {
        private String _query, _queryAll;
        private EntryListFieldList _fields;
        private EntryFieldValueList _results, _allGroups;

        public const int GROUP_NAME = 536870925;
        public const int GROUP_ID = 536870939;
        public const int DIVISION_ID = 536870914;
        public const int UID = 536870922;
        public const int STATUS = 7;
        public const int PRIMARY_GROUP = 536870919;
        public const int PRIVATE_USER = 536870921;


        public UNCContactsOrgGroup(BMC.ARSystem.Server ARServer, string onyen)
        {
            _fields = new EntryListFieldList();
            _fields.AddField(GROUP_NAME, 50, ""); // Group Name
            _fields.AddField(GROUP_ID, 50, ""); // Group ID
            _fields.AddField(DIVISION_ID, 50, ""); // Division ID

            _query = "'" + UID.ToString() + "' = \"" + onyen + "\" AND '" + STATUS.ToString() + "' = 0 AND '" + PRIMARY_GROUP.ToString() + "' = \"Yes\" AND '" + PRIVATE_USER + "' = \"No\"";
            _results = ARServer.GetListEntryWithFields("UNC-Contacts", _query, _fields, 0, 0);

            _queryAll = "'" + UID.ToString() + "' = \"" + onyen + "\" AND '" + STATUS.ToString() + "' = 0  AND '" + PRIVATE_USER.ToString() + "' = \"No\"";
            _allGroups = ARServer.GetListEntryWithFields("UNC-Contacts", _queryAll, _fields, 0, 0);
        }

        //in theory, this returns all fields
        public UNCContactsOrgGroup(BMC.ARSystem.Server ARServer)
        {
            _fields = new EntryListFieldList();
            _fields.AddField(GROUP_NAME, 50, ""); // Group Name

            _queryAll = "'" + STATUS.ToString() + "' = \"Active\"";
            _allGroups = ARServer.GetListEntryWithFields("UNC-Contacts", _queryAll, _fields, 0, 0);

        }
        public EntryFieldValueList GetAllOrgGroups
        {
            get
            {
                return _allGroups;
            }
        }

        public String GetPrimaryGroupName
        {
            get
            {
                if (_results.Count == 0)
                {
                    return "no Results";
                }
                else
                {
                    if (_results[0].FieldValues[GROUP_NAME] != null)
                    {
                        return _results[0].FieldValues[GROUP_NAME].ToString();
                    }
                    else
                    {
                        return "Unknown";
                    }
                }
            }
        }

        public string GetPrimaryGroupID
        {
            get
            {
                if (_results[0].FieldValues[GROUP_ID] != null)
                {
                    return _results[0].FieldValues[GROUP_ID].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }

        public string GetPrimaryDivisionID
        {
            get
            {
                if (_results[0].FieldValues[DIVISION_ID] != null)
                {
                    return _results[0].FieldValues[DIVISION_ID].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
    }

    /// <summary>
    /// Class Definition for the Remedy Form "UNC Group Assigned Lookup".  This form holds the associations between groups.
    /// Use this class when you want to present a user a list of groups that they would see under Group Assigned in the Client.
    /// </summary>
    public class UNCGroupAssignedLookup
    {
        private String _query;
        private String[] _orgGroups;
        private EntryListFieldList _fields;
        private EntryFieldValueList _results;

        public const int DESTINATION_ORGGROUP = 536870914;
        public const int ORGGROUP_ID = 536870915;
        public const int STATUS = 7;

        public UNCGroupAssignedLookup(BMC.ARSystem.Server ARServer, string orgGroupID)
        {
            _fields = new EntryListFieldList();
            _fields.AddField(DESTINATION_ORGGROUP, 50, "");

            _query = "'" + ORGGROUP_ID.ToString() + "' = " + orgGroupID + " AND '" + STATUS.ToString() + "' = 0";
            _results = ARServer.GetListEntryWithFields("UNC-Group Assigned Lookup", _query, _fields, 0, 0);
        }

        public EntryFieldValueList GetSearchResults
        {
            get
            {
                return _results;
            }
        }
    }

    /// <summary>
    /// Class Definition 2 for the Remedy Form "Contacts".  This form holds User data and group association.  Use this function
    /// to present the active members of a group.  It mimics the functionality of Person Assigned.
    /// </summary>
    public class UNCContactsPersonAssigned
    {
        private String _query;
        private String[] _orgGroups;
        private EntryListFieldList _fields;
        private EntryFieldValueList _results;

        public const int ORGGROUP_ID = 536870939;
        public const int PERSON_ASSIGNED = 536870922;
        public const int STATUS = 7;

        public UNCContactsPersonAssigned(BMC.ARSystem.Server ARServer, string orgGroupID)
        {
            _fields = new EntryListFieldList();
            _fields.AddField(PERSON_ASSIGNED, 50, "");
            //ORGGROUP_ID = 536870925;

            _query = "'" + ORGGROUP_ID.ToString() + "' = " + orgGroupID + " AND '" + STATUS.ToString() + "' = 0";
            _results = ARServer.GetListEntryWithFields("UNC-Contacts", _query, _fields, 0, 0);


            //    "'" & GROUP_NAME.ToString() & "' = """ & groupName & """ AND '" & STATUS.ToString() & "' = 0 AND '" & _
            //   NOT_INTENDED_FOR_OUR_VIEWING_AUDIENCE.ToString & "' = 0";
        }

        public EntryFieldValueList GetSearchResults
        {
            get
            {
                return _results;
            }
        }
    }

    /// <summary>
    /// Class Definition for the Remedy Form "UNC-Campus Short Descriptions".  This form holds the Short Descriptions
    /// for each orggroup that uses RFS.  Use this class when you want to return Short Descriptions for a given group.
    /// </summary>
    public class UNCCampusShortDescriptions
    {
        private String _query;  // The query used to retrieve the form data from Remedy
        private EntryListFieldList _fields; // A list of fields to be included in the results
        private EntryFieldValueList _results; // All of the entries and fields returned by the query

        public const int SHORT_DESCRIPTION = 8;
        public const int STATUS = 7;
        public const int CATEGORY = 536871242;
        public const int TOPIC = 536870923;
        public const int ITEM = 536870913;
        public const int ORG_GROUP_ID = 536870916;

        /**************************************************************
        Constructor #1: User passes Org Group ID as a string for query
        **************************************************************/
        public UNCCampusShortDescriptions(BMC.ARSystem.Server ARServer, string orgGroupID)
        {
            /* Add fields to list to be retrieved by query*/
            _fields = new EntryListFieldList();
            _fields.AddField(SHORT_DESCRIPTION, 50, "");  // Short Description
            _fields.AddField(CATEGORY, 50, ""); // Category
            _fields.AddField(TOPIC, 50, ""); // Topic
            _fields.AddField(ITEM, 50, ""); // Item


            _query = "'" + ORG_GROUP_ID.ToString() + "' = " + orgGroupID + " AND '" + STATUS.ToString() + "' = 0"; // Query for the Remedy Form: 'Field Number(OrgGroupID)' = "orgGroupID" AND 'Field Number(Status)' = "0"
            _results = ARServer.GetListEntryWithFields("UNC-Campus Short Descriptions", _query, _fields, 0, 0); // Actually Query The Form
        }

        /*************************************************************************
        GetSearchResults: Return all results as an EntryFieldValueList
        **************************************************************************/
        public EntryFieldValueList GetSearchResults
        {
            get
            {
                return _results;
            }
        }
    }


    /// <summary>
    /// Class Definition for the Remedy Form "UNC-Campus Secondary Category".  This form holds the Categories
    /// for each orggroup that uses RFS.  Use this class when you want to return Categories for a given group.
    /// </summary>
    public class UNCCampusSecondaryCategory
    {
        private String _query;
        private EntryListFieldList _fields;
        private EntryFieldValueList _results;

        public const int CATEGORY = 536871242;
        public const int STATUS = 7;
        public const int ORG_GROUP_ID = 536870920;

        public UNCCampusSecondaryCategory(BMC.ARSystem.Server ARServer, string orgGroupID)
        {
            _fields = new EntryListFieldList();
            _fields.AddField(CATEGORY, 50, "");  // Categories

            _query = "'" + ORG_GROUP_ID.ToString() + "' = " + orgGroupID + " AND '" + STATUS.ToString() + "' = 0";
            _results = ARServer.GetListEntryWithFields("UNC-Campus Secondary Category", _query, _fields, 0, 0);
        }

        public EntryFieldValueList GetSearchResults
        {
            get
            {
                return _results;
            }
        }
    }
    /// <summary>
    /// Class Definition for the Remedy Form "UNC-Campus Topic Affected".  This form holds the Topics Affected
    /// for each orggroup that uses RFS.  Use this class when you want to return Topics Affected for a given group.
    /// </summary>
    public class UNCCampusTopicAffected
    {
        private String _query;
        private EntryListFieldList _fields;
        private EntryFieldValueList _results;

        public const int ORGGROUP_ID = 536870916;
        public const int TOPIC_AFFECTED = 536870913;
        public const int CATEGORY = 536871242;
        public const int STATUS = 7;

        public UNCCampusTopicAffected(BMC.ARSystem.Server ARServer, string orgGroupID, string category)
        {
            _fields = new EntryListFieldList();
            _fields.AddField(TOPIC_AFFECTED, 50, "");

            _query = "'" + ORGGROUP_ID.ToString() + "' = " + orgGroupID + " AND '" + CATEGORY.ToString() + "' = \"" + category + "\" AND '" + STATUS.ToString() + "' = 0";
            _results = ARServer.GetListEntryWithFields("UNC-Campus Topic Affected", _query, _fields, 0, 0);
        }

        public EntryFieldValueList GetSearchResults
        {
            get
            {
                return _results;
            }
        }
    }

    /// <summary>
    /// Class Definition for the Remedy Form "UNC-Campus Item Affected".  This form holds the Items Affected
    /// for each orggroup that uses RFS.  Use this class when you want to return Items Affected for a given group.
    /// </summary>
    public class UNCCampusItemAffected
    {
        private String _query;
        private EntryListFieldList _fields;
        private EntryFieldValueList _results;

        public const int ITEM_AFFECTED = 536870922;
        public const int ORGGROUP_ID = 536870916;
        public const int TOPIC_AFFECTED = 536870913;
        public const int CATEGORY = 536871242;
        public const int STATUS = 7;


        public UNCCampusItemAffected(BMC.ARSystem.Server ARServer, string orgGroupID, string category, string topic)
        {
            _fields = new EntryListFieldList();
            _fields.AddField(ITEM_AFFECTED, 50, "");

            _query = "'" + ORGGROUP_ID.ToString() + "' = " + orgGroupID + " AND '" + CATEGORY.ToString() + "' = \"" + category + "\" AND '" + TOPIC_AFFECTED.ToString() + "' = \"" + topic + "\" AND '" + STATUS.ToString() + "' = 0";
            _results = ARServer.GetListEntryWithFields("UNC-Campus Item Affected", _query, _fields, 0, 0);
        }

        public EntryFieldValueList GetSearchResults
        {
            get
            {
                return _results;
            }
        }
    }

    /// <summary>
    /// Class Definition for the Remedy Form "UNC-OrgGroupBuildings".  This form holds the Buildings supported
    /// for each orggroup that uses RFS.  Use this class when you want to return Buldings supported for a given group.
    /// *Note, this functionality is not commonly used.
    /// </summary>
    public class UNCOrgGroupBuildings
    {
        private String _query;
        private EntryListFieldList _fields;
        private EntryFieldValueList _results;

        public const int ORGGROUP_ID = 536870939;
        public const int LOCATION = 536870913;
        public const int STATUS = 7;

        public UNCOrgGroupBuildings(BMC.ARSystem.Server ARServer, string orgGroupID)
        {
            _fields = new EntryListFieldList();
            _fields.AddField(LOCATION, 50, "");

            _query = "'" + ORGGROUP_ID.ToString() + "' = " + orgGroupID + " AND '" + STATUS.ToString() + "' = 0";
            _results = ARServer.GetListEntryWithFields("UNC-OrgGroup Buildings", _query, _fields, 0, 0);
        }

        public EntryFieldValueList GetSearchResults
        {
            get
            {
                return _results;
            }
        }
    }

    //This class should, in theory, return the number of tickets created, touched, or solved in the last 7 days

    //{UNC_Request_for_Service.Create Date} in DateTime (2011, 01, 01, 00, 00, 00) to DateTime (2011, 06, 30, 23, 59, 59) and
    //{UNC_Request_for_Service.Group Created} = "ITRC-ANALYSTS"
    /*
    public class NumberOfTickets
    {
        public const int CREATE_DATE = ;
        public const int GROUP_CREATED = ;

    */


    //This class should utilize the Tables UNC_GROUP_DESCRIPTION
    //This class is here so we can look up the fields Group_Description and Types_Of_Tickets_Handled from UNC_GROUP_DESCRIPTION
    //The point of this is to grab these fields and be able to dump into an access database we can search

    public class GroupDescriptionToAccess
    {
        public const int GROUP_DESCRIPTION = 536870913;
        public const int TICKETS_HANDLED = 536870919;
        public const int ORGGROUPPLUS = 536870917;  //this is the name of the orggroup, ie ITRC-ANALYSTS

        private String _query;
        private EntryListFieldList _fields;
        private EntryFieldValueList _results;

        public GroupDescriptionToAccess(BMC.ARSystem.Server ARServer, string orgGroupName)
        {
            _fields = new EntryListFieldList();
            _fields.AddField(GROUP_DESCRIPTION, 50, "");
            _fields.AddField(TICKETS_HANDLED, 50, "");

            _query = "'" + ORGGROUPPLUS.ToString() + "' = \"" + orgGroupName + "\"";
            _results = ARServer.GetListEntryWithFields("UNC-Group Description", _query, _fields, 0, 0);
        }

        public String getDescription
        {
            get
            {
                try
                {
                    if (_results[0].FieldValues[GROUP_DESCRIPTION] != null)
                    {
                        return _results[0].FieldValues[GROUP_DESCRIPTION].ToString();
                    }
                    else
                    {
                        return "Unknown";
                    }
                }
                catch
                {
                    return "No data found in Remedy Tables.";
                }
            }
        }

        public String getTicketsHandled
        {
            get
            {
                try
                {

                    if (_results[0].FieldValues[TICKETS_HANDLED] != null)
                    {
                        return _results[0].FieldValues[TICKETS_HANDLED].ToString();
                    }
                    else
                    {
                        return "Unknown";
                    }
                }
                catch
                {
                    return "No data found in Remedy Tables.";
                }
            }
        }
    }

    //this class should get the open tickets of a group.  Currently set to ITRC-Analysts/ITS-Postmaster if not using the overloaded method
    //if using the overloaded method, you can send it the string[] of groups 
    public class getOpenTickets
    {
        public const int TICKET_NUMBER = 536870988;
        public const int GROUP_ASSIGNED = 536870929;
        public const int STATUS = 536871035;
        public const int ONYEN = 536871172;
        public const int PID = 536870917;
        public const int SHORT_DESC = 536870937;
        public const int PERSON_ASSIGNED = 536870931;
        public const int ENTRY_ID = 1;
        public const int CREATE_DATE = 3;
        public const int MOD_DATE = 6;
        public const int SYS_DATE_SOLVED = 536870920;
        public const int WEBSUBSUBMITTER = 536923371;//person that submitted request on behalf of customer
        public const int SYS_STATUS = 7;


        private String _query;
        private EntryListFieldList _fields;
        private EntryFieldValueList _results;
        private String groupsQuery = "(";
        public getOpenTickets(BMC.ARSystem.Server ARServer)
        {
            _fields = new EntryListFieldList();
            _fields.AddField(TICKET_NUMBER, 50, "");
            _fields.AddField(GROUP_ASSIGNED, 50, "");
            _fields.AddField(STATUS, 50, "");

            //modified query, slightly faster
            _query = "('" + GROUP_ASSIGNED.ToString() + "' = \"ITRC-ANALYSTS\") AND (" +
                "'" + STATUS.ToString() + "' = \"Assigned\" OR '" + STATUS.ToString() + "' = \"Work in Progress\" OR '" +
                STATUS.ToString() + "' = \"Pending Customer\" OR '" + STATUS.ToString() + "' = \"Pending Analyst\" OR '" + STATUS.ToString() + "' = \"Pending Vendor\")";
            //original query
            /*
            _query = "'" + GROUP_ASSIGNED.ToString() + "' = \"ITRC-ANALYSTS\" AND (" + "'" + STATUS.ToString() + "' = \"Assigned\" OR '" + STATUS.ToString() + "' = \"Work in Progress\" OR '" +
                STATUS.ToString() + "' = \"Pending Customer\" OR '" + STATUS.ToString() + "' = \"Pending Analyst\" OR '" + STATUS.ToString() + "' = \"Pending Vendor\") OR " + "'" + GROUP_ASSIGNED.ToString() +
                "' = \"ITS-POSTMASTER\" AND (" + "'" + STATUS.ToString() + "' = \"Assigned\" OR '" + STATUS.ToString() + "' = \"Work in Progress\" OR '" +
                STATUS.ToString() + "' = \"Pending Customer\" OR '" + STATUS.ToString() + "' = \"Pending Analyst\" OR '" + STATUS.ToString() + "' = \"Pending Vendor\")";  */
            Console.WriteLine(_query);
            _results = ARServer.GetListEntryWithFields("UNC-Request for Service", _query, _fields, 0, 0);
        }

        public getOpenTickets(BMC.ARSystem.Server ARServer, string group)//NEW METHOD FOR SEARCHING BASED ON ANY GROUP
        {
            _fields = new EntryListFieldList();
            _fields.AddField(TICKET_NUMBER, 50, "");
            _fields.AddField(GROUP_ASSIGNED, 50, "");
            _fields.AddField(STATUS, 50, "");

            //modified query, slightly faster
            _query = "('" + GROUP_ASSIGNED.ToString() + "' = \"" + group + "\") AND (" +
                "'" + STATUS.ToString() + "' = \"Assigned\" OR '" + STATUS.ToString() + "' = \"Work in Progress\" OR '" +
                STATUS.ToString() + "' = \"Pending Customer\" OR '" + STATUS.ToString() + "' = \"Pending Analyst\" OR '" + STATUS.ToString() + "' = \"Pending Vendor\")";

            Console.WriteLine(_query);
            _results = ARServer.GetListEntryWithFields("UNC-Request for Service", _query, _fields, 0, 0);
        }

        public getOpenTickets(BMC.ARSystem.Server ARServer, string pid, string formname, string OpnorClos)//NEW METHOD FOR SEARCHING BASED ON A USER'S PID, ALSO CHANGES THE FORM NAME ACCORDINGLY, and whether it is looking for open or closed tickets(LAST 5 MONTHS).
        {
            _fields = new EntryListFieldList();
            _fields.AddField(TICKET_NUMBER, 50, "");
            _fields.AddField(GROUP_ASSIGNED, 50, "");
            _fields.AddField(PERSON_ASSIGNED, 255, "");
            _fields.AddField(SHORT_DESC, 255, "");
            _fields.AddField(STATUS, 50, "");
            _fields.AddField(ENTRY_ID, 50, "");
            _fields.AddField(CREATE_DATE, 50, "");
            _fields.AddField(MOD_DATE, 50, "");
            _fields.AddField(PID, 50, "");
            _fields.AddField(WEBSUBSUBMITTER, 50, "");

            DateTime last6months = DateTime.Today.AddDays(-180);//6 months

            if (OpnorClos == "Open")
            {
                //modified query, slightly faster, also checks whether the pid matches the pid field or the websubmit submitter field so the person logged in can see all tickets submitted by them
                _query = "(('" + PID.ToString() + "' = \"" + pid + "\") OR  " + "('" + WEBSUBSUBMITTER.ToString() + "' = \"" + pid + "\")) AND ('" + SYS_STATUS.ToString() + "' < \"Solved\")";
            }
            else if (OpnorClos == "Solved")
            {
                //modified query, slightly faster//only 6 months worth of tickets
                _query = "(('" + PID.ToString() + "' = \"" + pid + "\") OR  " + "('" + WEBSUBSUBMITTER.ToString() + "' = \"" + pid + "\")) AND ('" + CREATE_DATE + "' >= \"" + last6months + "\"" + ") AND ('" + SYS_STATUS.ToString() + "' >= \"Solved\")";
            }





            //Console.WriteLine(_query);
            _results = ARServer.GetListEntryWithFields(formname, _query, _fields, 0, 0);
        }
        public getOpenTickets(BMC.ARSystem.Server ARServer, string[] groups)
        {
            _fields = new EntryListFieldList();
            _fields.AddField(TICKET_NUMBER, 50, "");
            _fields.AddField(GROUP_ASSIGNED, 50, "");
            _fields.AddField(STATUS, 50, "");
            //build the query for the groups
            for (int i = 0; i < groups.Length; i++)
            {
                string temp = "'" + GROUP_ASSIGNED.ToString() + "' = \"" + groups[i] + "\"";
                if (i < groups.Length - 1)
                {
                    temp += " OR ";
                }
                groupsQuery += temp;
            }
            groupsQuery += ") ";
            //add the groups to the default 'open ticket' statuses
            _query = groupsQuery + "AND (" + "'" + STATUS.ToString() + "' = \"Assigned\" OR '" + STATUS.ToString() + "' = \"Work in Progress\" OR '" +
                STATUS.ToString() + "' = \"Pending Customer\" OR '" + STATUS.ToString() + "' = \"Pending Analyst\" OR '" + STATUS.ToString() + "' = \"Pending Vendor\")";

            Console.WriteLine(_query);
            _results = ARServer.GetListEntryWithFields("UNC-Request for Service", _query, _fields, 0, 0);
        }
        public string getnum
        {
            get
            {
                try
                {
                    return _results.Count.ToString();
                }
                catch
                {
                    return "The getnum method inside getOpenTickets is not working";
                }
            }
        }
        /*************************************************************************
     GetSearchResults: Return all results as an EntryFieldValueList
     **************************************************************************/
        public EntryFieldValueList GetSearchResults
        {
            get
            {
                return _results;
            }
        }
    }

    //create date for the past 90 days
    //group created = itrc analysts

    public class getRFSInfo
    {
        //public const int DATE_SOLVED = 536870992;
        public const int DATE_SOLVED = 536870920;
        public const int GROUP_ASSIGNED = 536870929;
        public const int GROUP_CREATED = 536871036;
        public const int CREATE_DATE = 3;  //this is a TimeStamp field, has both the date and the time
        public const int SHORT_DESCRIPTION = 536870937;
        public const int CATEGORY = 536871242;
        public const int REQUEST_NUMBER = 536870988;
        public const int STATUS = 536871035;
        public const int PERSON_ASSIGNED = 536870931;
        public const int TICKET_NUMBER = 536870988;
        public const int CLIENTS_PROBLEM_DESCRIPTION = 536870955;
        public const int CUSTOMER_FIRST_NAME = 536870926;
        public const int CUSTOMER_LAST_NAME = 536870918;
        public const int CUSTOMER_MIDDLE_INITIAL = 536870966;
        public const int CUSTOMER_AFFILIATION = 536870969;
        public const int CUSTOMER_DEPARTMENT = 536870963;
        public const int CUSTOMER_TELEPHONE = 536870936;
        public const int CUSTOMER_LOCATION = 536870948;
        public const int CUSTOMER_EMAIL = 536870950;
        public const int CUSTOMER_ONYEN = 536871172;
        public const int CUSTOMER_PID = 536870917;
        public const int WORKLOG = 536870923;
        public const int ENTRY_ID = 1;//REAL TICKET NUMBER, WILL USE THIS TO MAKE THIS WORKABLE WITH THE FSU FORM
        public const int FOLLOW_UP_EMAIL = 536871083;
        public const int SYS_ORGGROUP_ID = 536870954;
        //Web Submit-specific fields

        public const int WEBSUBPRIMARY = 536923367;//primary category from web submit
        public const int WEBSUBSECONDARY = 536923368;//secondary category from web submit
        public const int WEBSUBTERTIARY = 536923369;//tertiary category from web submit
        public const int WEBSUBVERSION = 536923370;//field that holds the version of web submit
        public const int WEBSUBSUBMITTER = 536923371;//person that submitted request on behalf of customer
        public const int WEBSUBATTACHMENT = 536923373;//flag that will be set by web submit if an attachment was accepted 

        //Attachment Fields
        public const int ATTACHMENT_1 = 536908983;
        public const int ATTACHMENT_2 = 536908984;
        public const int ATTACHMENT_3 = 536908985;
        public const int ATTACHMENT_4 = 536908986;
        public const int ATTACHMENT_5 = 536908987;

        private String _query;
        private EntryListFieldList _fields;
        private EntryFieldValueList _results;

        public getRFSInfo(BMC.ARSystem.Server ARServer)
        {
            _fields = new EntryListFieldList();
            _fields.AddField(DATE_SOLVED);
            _fields.AddField(GROUP_ASSIGNED);
            _fields.AddField(GROUP_CREATED);
            _fields.AddField(CREATE_DATE);
            _fields.AddField(CATEGORY);
            _fields.AddField(REQUEST_NUMBER);
            _fields.AddField(STATUS);
            _fields.AddField(PERSON_ASSIGNED);
            _fields.AddField(ATTACHMENT_1);
            _fields.AddField(ATTACHMENT_2);
            _fields.AddField(ATTACHMENT_3);
            _fields.AddField(ATTACHMENT_4);
            _fields.AddField(ATTACHMENT_5);

            DateTime lastmonth = DateTime.Today.AddDays(-90);

            _query = "'" + GROUP_CREATED.ToString() + "' = \"ITRC-ANALYSTS\" AND '" + CREATE_DATE + "' >= \"" + lastmonth + "\"";
            _results = ARServer.GetListEntryWithFields("UNC-Request for Service", _query, _fields, 0, 0);
        }

        //this overloaded method asks for the time, in hours
        public getRFSInfo(BMC.ARSystem.Server ARServer, int hours)
        {
            _fields = new EntryListFieldList();
            _fields.AddField(DATE_SOLVED);
            _fields.AddField(GROUP_ASSIGNED);
            _fields.AddField(GROUP_CREATED);
            _fields.AddField(CREATE_DATE);
            _fields.AddField(CATEGORY);
            _fields.AddField(REQUEST_NUMBER);
            _fields.AddField(STATUS);
            _fields.AddField(PERSON_ASSIGNED);
            _fields.AddField(ATTACHMENT_1);
            _fields.AddField(ATTACHMENT_2);
            _fields.AddField(ATTACHMENT_3);
            _fields.AddField(ATTACHMENT_4);
            _fields.AddField(ATTACHMENT_5);

            DateTime numOfHours = DateTime.Now.AddHours(-hours);

            _query = "'" + GROUP_CREATED.ToString() + "' = \"ITRC-ANALYSTS\" AND '" + CREATE_DATE + "' >= \"" + numOfHours + "\"";
            _results = ARServer.GetListEntryWithFields("UNC-Request for Service", _query, _fields, 0, 0);
        }

        //overloaded method that pulls info based on ticket number


        public getRFSInfo(BMC.ARSystem.Server ARServer, string ticket, string formname)
        {
            _fields = new EntryListFieldList();
            _fields.AddField(TICKET_NUMBER);
            _fields.AddField(GROUP_ASSIGNED);
            _fields.AddField(GROUP_CREATED);
            _fields.AddField(CREATE_DATE);
            _fields.AddField(CATEGORY);
            _fields.AddField(ENTRY_ID);
            _fields.AddField(STATUS);
            _fields.AddField(PERSON_ASSIGNED);
            _fields.AddField(WORKLOG);
            _fields.AddField(SHORT_DESCRIPTION);
            _fields.AddField(FOLLOW_UP_EMAIL);
            _fields.AddField(CLIENTS_PROBLEM_DESCRIPTION);
            _fields.AddField(SYS_ORGGROUP_ID);
            _fields.AddField(WEBSUBPRIMARY);
            _fields.AddField(WEBSUBSECONDARY);
            _fields.AddField(WEBSUBTERTIARY);
            _fields.AddField(WEBSUBVERSION);
            _fields.AddField(CUSTOMER_FIRST_NAME);
            _fields.AddField(CUSTOMER_LAST_NAME);
            _fields.AddField(ATTACHMENT_1);
            _fields.AddField(ATTACHMENT_2);
            _fields.AddField(ATTACHMENT_3);
            _fields.AddField(ATTACHMENT_4);
            _fields.AddField(ATTACHMENT_5);

            _query = "'" + ENTRY_ID.ToString() + "' = \"" + ticket + "\"";
            //_query = "\"" + ENTRY_ID.ToString() + "\" LIKE \"" + ticket + "\"";
            _results = ARServer.GetListEntryWithFields(formname, _query, _fields, 0, 0);
        }





        public EntryFieldValueList getEverything
        {
            get
            {
                return _results;
            }
        }
        public string getFollowUp
        {
            get
            {
                if (_results[0].FieldValues[FOLLOW_UP_EMAIL] != null)
                {
                    return _results[0].FieldValues[FOLLOW_UP_EMAIL].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public string getWorklog
        {
            get
            {
                if (_results[0].FieldValues[WORKLOG] != null)
                {
                    return _results[0].FieldValues[WORKLOG].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }

        public string getOrgGroupID
        {
            get
            {
                if (_results[0].FieldValues[SYS_ORGGROUP_ID] != null)
                {
                    return _results[0].FieldValues[SYS_ORGGROUP_ID].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public string getCPD
        {
            get
            {
                if (_results[0].FieldValues[CLIENTS_PROBLEM_DESCRIPTION] != null)
                {
                    return _results[0].FieldValues[CLIENTS_PROBLEM_DESCRIPTION].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public string getSD
        {
            get
            {
                if (_results[0].FieldValues[SHORT_DESCRIPTION] != null)
                {
                    return _results[0].FieldValues[SHORT_DESCRIPTION].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public string getDateSolved
        {
            get
            {
                if (_results[0].FieldValues[DATE_SOLVED] != null)
                {
                    return _results[0].FieldValues[DATE_SOLVED].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public string getGroupAssigned
        {
            get
            {
                if (_results[0].FieldValues[GROUP_ASSIGNED] != null)
                {
                    return _results[0].FieldValues[GROUP_ASSIGNED].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public string getGroupCreated
        {
            get
            {
                if (_results[0].FieldValues[GROUP_CREATED] != null)
                {
                    return _results[0].FieldValues[GROUP_CREATED].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public DateTime getCreateDate
        {
            get
            {
                if (_results[0].FieldValues[CREATE_DATE] != null)
                {
                    return (DateTime)(_results[0].FieldValues[CREATE_DATE]);
                }
                else
                {
                    return DateTime.Now;
                }
            }
        }
        public string getCategory
        {
            get
            {
                if (_results[0].FieldValues[CATEGORY] != null)
                {
                    return _results[0].FieldValues[CATEGORY].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public string getRequestNumber
        {
            get
            {
                if (_results[0].FieldValues[REQUEST_NUMBER] != null)
                {
                    return _results[0].FieldValues[REQUEST_NUMBER].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public string getEntryID
        {
            get
            {
                if (_results[0].FieldValues[ENTRY_ID] != null)
                {
                    return _results[0].FieldValues[ENTRY_ID].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public string getStatus
        {
            get
            {
                if (_results[0].FieldValues[STATUS] != null)
                {
                    return _results[0].FieldValues[STATUS].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public string getPersonAssigned
        {
            get
            {
                if (_results[0].FieldValues[PERSON_ASSIGNED] != null)
                {
                    return _results[0].FieldValues[PERSON_ASSIGNED].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public string getWebSubmitPrimary
        {
            get
            {
                if (_results[0].FieldValues[WEBSUBPRIMARY] != null)
                {
                    return _results[0].FieldValues[WEBSUBPRIMARY].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public string getWebSubmitSecondary
        {
            get
            {
                if (_results[0].FieldValues[WEBSUBSECONDARY] != null)
                {
                    return _results[0].FieldValues[WEBSUBSECONDARY].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }

        public string getWebSubmitTertiary
        {
            get
            {
                if (_results[0].FieldValues[WEBSUBTERTIARY] != null)
                {
                    return _results[0].FieldValues[WEBSUBTERTIARY].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }

        public string getWebSubmitSubmitter
        {
            get
            {
                if (_results[0].FieldValues[WEBSUBSUBMITTER] != null)
                {
                    return _results[0].FieldValues[WEBSUBSUBMITTER].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public string getCustomerLastName
        {
            get
            {
                if (_results[0].FieldValues[CUSTOMER_LAST_NAME] != null)
                {
                    return _results[0].FieldValues[CUSTOMER_LAST_NAME].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public string getCustomerFirstName
        {
            get
            {
                if (_results[0].FieldValues[CUSTOMER_FIRST_NAME] != null)
                {
                    return _results[0].FieldValues[CUSTOMER_FIRST_NAME].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        /*   public int getWebSubmitVersion
          {
              get
              {
                  if (_results[0].FieldValues[WEBSUBVERSION] != null)
                  {
                      return (int)_results[0].FieldValues[WEBSUBVERSION];
                  }
                  else
                  {
                      return 0;
                  }
              }
          }
       
          public DateTime getDateSolved(int i)
          {
                  if (_results[i].FieldValues[DATE_SOLVED] != null)
                  {
                      return (DateTime)_results[i].FieldValues[DATE_SOLVED];
                  }
                  else
                  {
                      return DateTime.Now;
                  }
          }
          public string getGroupAssigned(int i)
          {
                  if (_results[i].FieldValues[GROUP_ASSIGNED] != null)
                  {
                      return _results[i].FieldValues[GROUP_ASSIGNED].ToString();
                  }
                  else
                  {
                      return "Unknown";
                  }
          }
          public string getGroupCreated(int i)
          {
                  if (_results[i].FieldValues[GROUP_CREATED] != null)
                  {
                      return _results[i].FieldValues[GROUP_CREATED].ToString();
                  }
                  else
                  {
                      return "Unknown";
                  }
          }
          public DateTime getCreateDate(int i)
          {
                  if (_results[i].FieldValues[CREATE_DATE] != null)
                  {
                      return (DateTime)_results[i].FieldValues[CREATE_DATE];
                  }
                  else
                  {
                      return DateTime.Now;
                  }
          }
          public string getCategory(int i)
          {
                  if (_results[i].FieldValues[CATEGORY] != null)
                  {
                      return _results[i].FieldValues[CATEGORY].ToString();
                  }
                  else
                  {
                      return "Unknown";
                  }
          }
          public string getRequestNumber(int i)
          {
                  if (_results[i].FieldValues[REQUEST_NUMBER] != null)
                  {
                      return _results[i].FieldValues[REQUEST_NUMBER].ToString();
                  }
                  else
                  {
                      return "Unknown";
                  }
          }
          public string getStatus(int i)
          {
                  if (_results[i].FieldValues[STATUS] != null)
                  {
                      return _results[i].FieldValues[STATUS].ToString();
                  }
                  else
                  {
                      return "Unknown";
                  }
          }
          */
    }
    //This class should retrieve the license state that tells us whether the user is an active remedy user or not.
    public class getLicenseState
    {
        public const int LICENSE_STATE = 109;
        public const int LOGIN_NAME = 101;

        private String _query;
        private EntryListFieldList _fields;
        private EntryFieldValueList _results;

        public getLicenseState(BMC.ARSystem.Server ARServer, string onyen)
        {
            _fields = new EntryListFieldList();
            _fields.AddField(LICENSE_STATE, 50, "");
            _fields.AddField(LOGIN_NAME, 50, "");

            _query = "'" + LOGIN_NAME.ToString() + "' = \"" + onyen + "\"";
            _results = ARServer.GetListEntryWithFields("User", _query, _fields, 0, 0);

        }



        /*************************************************************************
        GetLicense: Should return the License_State for the user
        **************************************************************************/
        public String GetLicense
        {
            get
            {
                if (_results[0].FieldValues[LICENSE_STATE] != null)
                {
                    return _results[0].FieldValues[LICENSE_STATE].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
    }

    public class UNCWebSubmit
    {
        private String _query;  // The query used to retrieve the form data from Remedy
        private EntryListFieldList _fields; // A list of fields to be included in the results
        private EntryFieldValueList _results; // All of the entries and fields returned by the query

        public const int PROBLEM_NAME = 536870930;
        public const int STATUS = 7;// 0=active 1=inactive
        public const int CATEGORY = 536870933;
        public const int PROBLEM_DESCRIPTION = 8;
        public const int GROUP_ASSIGNED = 4;
        public const int SEVERITY = 536870918;
        public const int QUESTION_TEXT = 536870919;
        public const int ORG_GROUP_ID = 536870926;
        public const int DEPARTMENT = 536870915;
        public const int CAMPUS = 536870917;

        /**************************************************************
        Constructor #1: User passes  Campus values as a string for query
        **************************************************************/
        public UNCWebSubmit(BMC.ARSystem.Server ARServer, string Campus)
        {
            /* Add fields to list to be retrieved by query*/
            _fields = new EntryListFieldList();
            _fields.AddField(PROBLEM_NAME, 255, "");  // Problem Name
            _fields.AddField(CATEGORY, 80, ""); // Category
            _fields.AddField(PROBLEM_DESCRIPTION, 254, ""); // Problem Description
            _fields.AddField(QUESTION_TEXT, 5000, ""); // QUESTION_TEXT
            _fields.AddField(DEPARTMENT, 255, "");//department


            _query = "'" + CAMPUS.ToString() + "' = \"" + Campus + "\" AND '" + STATUS.ToString() + "' = 0"; // Query for the Remedy Form: for all departments that are active
            _results = ARServer.GetListEntryWithFields("UNC-NewWebSubmit", _query, _fields, 0, 0); // Actually Query The Form
        }
        /**************************************************************
     Constructor #2: User passes  Campus and Department values as a string for query
     **************************************************************/
        public UNCWebSubmit(BMC.ARSystem.Server ARServer, string Campus, string Department)
        {
            /* Add fields to list to be retrieved by query*/
            _fields = new EntryListFieldList();
            _fields.AddField(PROBLEM_NAME, 255, "");  // Problem Name
            _fields.AddField(CATEGORY, 80, ""); // Category
            _fields.AddField(PROBLEM_DESCRIPTION, 254, ""); // Problem Description
            _fields.AddField(QUESTION_TEXT, 5000, ""); // QUESTION_TEXT


            _query = "'" + CAMPUS.ToString() + "' = \"" + Campus + "\" AND '" + STATUS.ToString() + "' = 0" + " AND '" + DEPARTMENT.ToString() + "' = \"" + Department + "\""; // Query for the Remedy Form: 'Field Number(OrgGroupID)' = "orgGroupID" AND 'Field Number(Status)' = "0"
            _results = ARServer.GetListEntryWithFields("UNC-NewWebSubmit", _query, _fields, 0, 0); // Actually Query The Form
        }
        /**************************************************************
         Constructor #3: User passes Category as a string for query to retrieve more values
         **************************************************************/
        public UNCWebSubmit(BMC.ARSystem.Server ARServer, string Campus, string Department, string category)
        {
            /* Add fields to list to be retrieved by query*/
            _fields = new EntryListFieldList();
            _fields.AddField(PROBLEM_NAME, 255, "");  // Problem Name
            _fields.AddField(CATEGORY, 80, ""); // Category
            _fields.AddField(PROBLEM_DESCRIPTION, 254, ""); // Problem Description
            _fields.AddField(QUESTION_TEXT, 5000, ""); // QUESTION_TEXT


            _query = "'" + CAMPUS.ToString() + "' = \"" + Campus + "\" AND '" + CATEGORY.ToString() + "' = \"" + category + "\" AND '" + STATUS.ToString() + "' = 0" + " AND '" + DEPARTMENT.ToString() + "' = \"" + Department + "\"";
            _results = ARServer.GetListEntryWithFields("UNC-NewWebSubmit", _query, _fields, 0, 0); // Actually Query The Form
        }
        /**************************************************************
        Constructor #4: User passes Category and Problem Name as a string for query to retrieve more values
        **************************************************************/
        public UNCWebSubmit(BMC.ARSystem.Server ARServer, string Campus, string Department, string category, string problem_name)
        {
            /* Add fields to list to be retrieved by query*/
            _fields = new EntryListFieldList();
            _fields.AddField(PROBLEM_NAME, 255, "");  // Problem Name
            _fields.AddField(CATEGORY, 80, ""); // Category
            _fields.AddField(PROBLEM_DESCRIPTION, 254, ""); // Problem Description
            _fields.AddField(QUESTION_TEXT, 5000, ""); // QUESTION_TEXT
            _fields.AddField(GROUP_ASSIGNED, 250, ""); // Group Assigned



            _query = "'" + CAMPUS.ToString() + "' = \"" + Campus + "\" AND '" + CATEGORY.ToString() + "' = \"" + category + "\" AND '" + STATUS.ToString() + "' = 0" + " AND '" + DEPARTMENT.ToString() + "' = \"" + Department + "\"" + " AND '" + PROBLEM_NAME.ToString() + "' = \"" + problem_name + "\"";
            _results = ARServer.GetListEntryWithFields("UNC-NewWebSubmit", _query, _fields, 0, 0); // Actually Query The Form
        }

        /*************************************************************************
        GetSearchResults: Return all results as an EntryFieldValueList
        **************************************************************************/
        public EntryFieldValueList GetSearchResults
        {
            get
            {
                return _results;
            }
        }


        public String GetQuestions
        {
            get
            {
                if (_results[0].FieldValues[QUESTION_TEXT] != null)
                {
                    return _results[0].FieldValues[QUESTION_TEXT].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetProblemDesc
        {
            get
            {
                if (_results[0].FieldValues[PROBLEM_DESCRIPTION] != null)
                {
                    return _results[0].FieldValues[PROBLEM_DESCRIPTION].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetGroupAssigned
        {
            get
            {
                if (_results[0].FieldValues[GROUP_ASSIGNED] != null)
                {
                    return _results[0].FieldValues[GROUP_ASSIGNED].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetOrGroupID
        {
            get
            {
                if (_results[0].FieldValues[ORG_GROUP_ID] != null)
                {
                    return _results[0].FieldValues[ORG_GROUP_ID].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public string getnum
        {
            get
            {
                try
                {
                    return _results.Count.ToString();
                }
                catch
                {
                    return "The getnum method inside getOpenTickets is not working";
                }
            }
        }



    }

    public class UNCWebSubmitPrimary//New form for Web Submit Primary Support Option
    {
        private String _query;  // The query used to retrieve the form data from Remedy
        private EntryListFieldList _fields; // A list of fields to be included in the results
        private EntryFieldValueList _results; // All of the entries and fields returned by the query

        public const int PROBLEM_NAME = 536870930;
        public const int STATUS = 7;// 0=active 1=inactive
        // public const int CATEGORY = 536870933;
        public const int PROBLEM_DESCRIPTION = 8;
        public const int GROUP_ASSIGNED = 4;
        public const int SEVERITY = 536870918;
        //  public const int QUESTION_TEXT = 536870919;
        public const int ORG_GROUP_ID = 536870926;
        public const int DEPARTMENT = 536870915;//Primary support option
        public const int CAMPUS = 536870917;
        public const int INTDEPTID = 536870920;//int dept ID

        /**************************************************************
        Constructor #1: User passes  Campus values as a string for query
        **************************************************************/
        public UNCWebSubmitPrimary(BMC.ARSystem.Server ARServer, string Campus)
        {
            /* Add fields to list to be retrieved by query*/
            _fields = new EntryListFieldList();
            _fields.AddField(PROBLEM_NAME, 255, "");  // Problem Name
            _fields.AddField(PROBLEM_DESCRIPTION, 254, ""); // Problem Description
            _fields.AddField(DEPARTMENT, 255, "");//department


            _query = "'" + CAMPUS.ToString() + "' = \"" + Campus + "\" AND '" + STATUS.ToString() + "' = 0"; // Query for the Remedy Form: for all departments that are active
            _results = ARServer.GetListEntryWithFields("UNC-WebSubmit-Primary", _query, _fields, 0, 0); // Actually Query The Form
        }
        /**************************************************************
     Constructor #2: User passes  Campus and Dept ID values as a string for query
     **************************************************************/
        public UNCWebSubmitPrimary(BMC.ARSystem.Server ARServer, string Campus, string intDeptID)
        {
            /* Add fields to list to be retrieved by query*/
            _fields = new EntryListFieldList();
            _fields.AddField(DEPARTMENT, 255, "");//department
            _fields.AddField(INTDEPTID, 255, "");//department

            _query = "'" + CAMPUS.ToString() + "' = \"" + Campus + "\" AND '" + STATUS.ToString() + "' = 0" + " AND '" + INTDEPTID.ToString() + "' = \"" + intDeptID + "\""; // Query for the Remedy Form: 'Field Number(OrgGroupID)' = "orgGroupID" AND 'Field Number(Status)' = "0"
            _results = ARServer.GetListEntryWithFields("UNC-WebSubmit-Primary", _query, _fields, 0, 0); // Actually Query The Form
        }


        /*************************************************************************
        GetSearchResults: Return all results as an EntryFieldValueList
        **************************************************************************/
        public EntryFieldValueList GetSearchResults
        {
            get
            {
                return _results;
            }
        }
        public String GetDept
        {
            get
            {
                if (_results[0].FieldValues[DEPARTMENT] != null)
                {
                    return _results[0].FieldValues[DEPARTMENT].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetGroupAssigned
        {
            get
            {
                if (_results[0].FieldValues[GROUP_ASSIGNED] != null)
                {
                    return _results[0].FieldValues[GROUP_ASSIGNED].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetOrGroupID
        {
            get
            {
                if (_results[0].FieldValues[ORG_GROUP_ID] != null)
                {
                    return _results[0].FieldValues[ORG_GROUP_ID].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public string getnum
        {
            get
            {
                try
                {
                    return _results.Count.ToString();
                }
                catch
                {
                    return "The getnum method inside getOpenTickets is not working";
                }
            }
        }



    }

    public class UNCWebSubmitSecondary
    {
        private String _query;  // The query used to retrieve the form data from Remedy
        private EntryListFieldList _fields; // A list of fields to be included in the results
        private EntryFieldValueList _results; // All of the entries and fields returned by the query

        // public const int PROBLEM_NAME = 536870930;
        public const int STATUS = 7;// 0=active 1=inactive
        public const int CATEGORY = 536870933;
        public const int PROBLEM_DESCRIPTION = 8;
        public const int GROUP_ASSIGNED = 4;
        public const int SEVERITY = 536870918;
        //public const int QUESTION_TEXT = 536870919;
        public const int ORG_GROUP_ID = 536870926;
        public const int DEPARTMENT = 536870915;
        public const int CAMPUS = 536870917;

        /**************************************************************
        Constructor #1: User passes  Campus values as a string for query
        **************************************************************/
        public UNCWebSubmitSecondary(BMC.ARSystem.Server ARServer, string Campus)
        {
            /* Add fields to list to be retrieved by query*/
            _fields = new EntryListFieldList();
            _fields.AddField(CATEGORY, 80, ""); // Category
            _fields.AddField(PROBLEM_DESCRIPTION, 254, ""); // Problem Description
            _fields.AddField(DEPARTMENT, 255, "");//department


            _query = "'" + CAMPUS.ToString() + "' = \"" + Campus + "\" AND '" + STATUS.ToString() + "' = 0"; // Query for the Remedy Form: for all departments that are active
            _results = ARServer.GetListEntryWithFields("UNC-WebSubmit-Secondary", _query, _fields, 0, 0); // Actually Query The Form
        }
        /**************************************************************
     Constructor #2: User passes  Campus and Department values as a string for query
     **************************************************************/
        public UNCWebSubmitSecondary(BMC.ARSystem.Server ARServer, string Campus, string Department)
        {
            /* Add fields to list to be retrieved by query*/
            _fields = new EntryListFieldList();
            _fields.AddField(CATEGORY, 80, ""); // Category
            _fields.AddField(PROBLEM_DESCRIPTION, 254, ""); // Problem Description



            _query = "'" + CAMPUS.ToString() + "' = \"" + Campus + "\" AND '" + STATUS.ToString() + "' = 0" + " AND '" + DEPARTMENT.ToString() + "' = \"" + Department + "\""; // Query for the Remedy Form: 'Field Number(OrgGroupID)' = "orgGroupID" AND 'Field Number(Status)' = "0"
            _results = ARServer.GetListEntryWithFields("UNC-WebSubmit-Secondary", _query, _fields, 0, 0); // Actually Query The Form
        }
        /**************************************************************
         Constructor #3: User passes Category as a string for query to retrieve more values
         **************************************************************/
        public UNCWebSubmitSecondary(BMC.ARSystem.Server ARServer, string Campus, string Department, string category)
        {
            /* Add fields to list to be retrieved by query*/
            _fields = new EntryListFieldList();
            _fields.AddField(CATEGORY, 80, ""); // Category
            _fields.AddField(PROBLEM_DESCRIPTION, 254, ""); // Problem Description



            _query = "'" + CAMPUS.ToString() + "' = \"" + Campus + "\" AND '" + CATEGORY.ToString() + "' = \"" + category + "\" AND '" + STATUS.ToString() + "' = 0" + " AND '" + DEPARTMENT.ToString() + "' = \"" + Department + "\"";
            _results = ARServer.GetListEntryWithFields("UNC-WebSubmit-Secondary", _query, _fields, 0, 0); // Actually Query The Form
        }



        /*************************************************************************
        GetSearchResults: Return all results as an EntryFieldValueList
        **************************************************************************/
        public EntryFieldValueList GetSearchResults
        {
            get
            {
                return _results;
            }
        }



        public String GetGroupAssigned
        {
            get
            {
                if (_results[0].FieldValues[GROUP_ASSIGNED] != null)
                {
                    return _results[0].FieldValues[GROUP_ASSIGNED].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetOrGroupID
        {
            get
            {
                if (_results[0].FieldValues[ORG_GROUP_ID] != null)
                {
                    return _results[0].FieldValues[ORG_GROUP_ID].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public string getnum
        {
            get
            {
                try
                {
                    return _results.Count.ToString();
                }
                catch
                {
                    return "The getnum method inside getOpenTickets is not working";
                }
            }
        }



    }

    public class UNCWebSubmitTertiary
    {
        private String _query;  // The query used to retrieve the form data from Remedy
        private EntryListFieldList _fields; // A list of fields to be included in the results
        private EntryFieldValueList _results; // All of the entries and fields returned by the query

        public const int PROBLEM_NAME = 536870930;//secondary category
        public const int STATUS = 7;// 0=active 1=inactive
        public const int CATEGORY = 536870933;//primary category
        public const int PROBLEM_DESCRIPTION = 8;//keywords
        public const int GROUP_ASSIGNED = 4;
        public const int PERSON_ASSIGNED = 536870922;
        public const int SEVERITY = 536870918;
        public const int QUESTION_TEXT = 536870919;
        public const int ORG_GROUP_ID = 536870926;
        public const int DEPARTMENT = 536870915;//support organization or service
        public const int CAMPUS = 536870917;
        public const int WEIGHT = 536870924;



        /**************************************************************
        Constructor #1: User passes  Campus values as a string for query
        **************************************************************/
        public UNCWebSubmitTertiary(BMC.ARSystem.Server ARServer, string Campus)
        {
            /* Add fields to list to be retrieved by query*/
            _fields = new EntryListFieldList();
            _fields.AddField(PROBLEM_NAME, 255, "");  // Problem Name
            _fields.AddField(CATEGORY, 80, ""); // Category
            _fields.AddField(PROBLEM_DESCRIPTION, 254, ""); // Problem Description
            _fields.AddField(QUESTION_TEXT, 5000, ""); // QUESTION_TEXT
            _fields.AddField(DEPARTMENT, 255, "");//department
            _fields.AddField(GROUP_ASSIGNED, 250, ""); // Group Assigned
            _fields.AddField(WEIGHT, 5000, ""); // weight


            _query = "'" + CAMPUS.ToString() + "' = \"" + Campus + "\" AND '" + STATUS.ToString() + "' = 0"; // Query for the Remedy Form: for all departments that are active
            _results = ARServer.GetListEntryWithFields("UNC-WebSubmit-Tertiary", _query, _fields, 0, 0); // Actually Query The Form
        }
        /**************************************************************
     Constructor #2: User passes  Campus and Department values as a string for query
     **************************************************************/
        public UNCWebSubmitTertiary(BMC.ARSystem.Server ARServer, string Campus, string Department)
        {
            /* Add fields to list to be retrieved by query*/
            _fields = new EntryListFieldList();
            _fields.AddField(PROBLEM_NAME, 255, "");  // Problem Name
            _fields.AddField(CATEGORY, 80, ""); // Category
            _fields.AddField(PROBLEM_DESCRIPTION, 254, ""); // Problem Description
            _fields.AddField(QUESTION_TEXT, 5000, ""); // QUESTION_TEXT


            _query = "'" + CAMPUS.ToString() + "' = \"" + Campus + "\" AND '" + STATUS.ToString() + "' = 0" + " AND '" + DEPARTMENT.ToString() + "' = \"" + Department + "\""; // Query for the Remedy Form: 'Field Number(OrgGroupID)' = "orgGroupID" AND 'Field Number(Status)' = "0"
            _results = ARServer.GetListEntryWithFields("UNC-WebSubmit-Tertiary", _query, _fields, 0, 0); // Actually Query The Form
        }
        /**************************************************************
         Constructor #3: User passes Category as a string for query to retrieve more values
         **************************************************************/
        public UNCWebSubmitTertiary(BMC.ARSystem.Server ARServer, string Campus, string Department, string category)
        {
            /* Add fields to list to be retrieved by query*/
            _fields = new EntryListFieldList();
            _fields.AddField(PROBLEM_NAME, 255, "");  // Problem Name
            _fields.AddField(CATEGORY, 80, ""); // Category
            _fields.AddField(PROBLEM_DESCRIPTION, 254, ""); // Problem Description
            _fields.AddField(QUESTION_TEXT, 5000, ""); // QUESTION_TEXT


            _query = "'" + CAMPUS.ToString() + "' = \"" + Campus + "\" AND '" + CATEGORY.ToString() + "' = \"" + category + "\" AND '" + STATUS.ToString() + "' = 0" + " AND '" + DEPARTMENT.ToString() + "' = \"" + Department + "\"";
            _results = ARServer.GetListEntryWithFields("UNC-WebSubmit-Tertiary", _query, _fields, 0, 0); // Actually Query The Form
        }
        /**************************************************************
        Constructor #4: User passes Category and Problem Name as a string for query to retrieve more values
        **************************************************************/
        public UNCWebSubmitTertiary(BMC.ARSystem.Server ARServer, string Campus, string Department, string category, string problem_name)
        {
            /* Add fields to list to be retrieved by query*/
            _fields = new EntryListFieldList();
            _fields.AddField(PROBLEM_NAME, 255, "");  // Problem Name
            _fields.AddField(CATEGORY, 80, ""); // Category
            _fields.AddField(PROBLEM_DESCRIPTION, 254, ""); // Problem Description
            _fields.AddField(QUESTION_TEXT, 5000, ""); // QUESTION_TEXT
            _fields.AddField(GROUP_ASSIGNED, 250, ""); // Group Assigned
            _fields.AddField(PERSON_ASSIGNED, 250, ""); // Group Assigned


            _query = "'" + CAMPUS.ToString() + "' = \"" + Campus + "\" AND '" + CATEGORY.ToString() + "' = \"" + category + "\" AND '" + STATUS.ToString() + "' = 0" + " AND '" + DEPARTMENT.ToString() + "' = \"" + Department + "\"" + " AND '" + PROBLEM_NAME.ToString() + "' = \"" + problem_name + "\"";
            _results = ARServer.GetListEntryWithFields("UNC-WebSubmit-Tertiary", _query, _fields, 0, 0); // Actually Query The Form
        }

        /*************************************************************************
        GetSearchResults: Return all results as an EntryFieldValueList
        **************************************************************************/
        public EntryFieldValueList GetSearchResults
        {
            get
            {
                return _results;
            }
        }


        public String GetQuestions
        {
            get
            {
                if (_results[0].FieldValues[QUESTION_TEXT] != null)
                {
                    return _results[0].FieldValues[QUESTION_TEXT].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetProblemDesc
        {
            get
            {
                if (_results[0].FieldValues[PROBLEM_DESCRIPTION] != null)
                {
                    return _results[0].FieldValues[PROBLEM_DESCRIPTION].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetGroupAssigned
        {
            get
            {
                if (_results[0].FieldValues[GROUP_ASSIGNED] != null)
                {
                    return _results[0].FieldValues[GROUP_ASSIGNED].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetPersonAssigned
        {
            get
            {
                if (_results[0].FieldValues[PERSON_ASSIGNED] != null)
                {
                    return _results[0].FieldValues[PERSON_ASSIGNED].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }

        public String GetOrGroupID
        {
            get
            {
                if (_results[0].FieldValues[ORG_GROUP_ID] != null)
                {
                    return _results[0].FieldValues[ORG_GROUP_ID].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public string getnum
        {
            get
            {
                try
                {
                    return _results.Count.ToString();
                }
                catch
                {
                    return "The getnum method inside getOpenTickets is not working";
                }
            }
        }
    }

    public class UNCRSEmailIn
    {
        private String _query;
        private EntryListFieldList _fields;
        private EntryFieldValueList _results;

        public const int STATUS = 7;
        public const int EMAIL_IDENTIFICATION = 536870913;
        public const int ORGANIZATION_GROUP = 536870914;
        public const int STATUS1 = 536871035;
        public const int SEND_EMAIL_TO_CLIENT = 536870923;
        public const int FOLLOW_UP_EMAIL = 536871083;
        public const int SYS_AFFILIATION = 536870925;
        public const int STUDENT_OR_OTHERS = 536870969;
        public const int PID = 536870917;
        public const int LAST_NAME = 536870918;
        public const int FIRST_NAME = 536870926;
        public const int MIDDLE_INITIAL = 536870966;
        public const int SOURCE = 536870924; //Point of contact
        public const int PHONE = 536870936;
        public const int EMAIL = 536870950;
        public const int SHORT_DESCRIPTION = 536870937;
        public const int CATEGORY = 536871242;
        public const int GROUP_ASSIGNED = 536870929;
        public const int PROBLEM_DESCRIPTION = 536870955;
        public const int TOPIC_AFFECTED = 536870939;
        public const int ITEM_AFFECTED = 536870932;
        public const int PERSON_ASSIGNED = 536870931;
        public const int SEVERITY_MENU = 536871069;
        public const int ORG_ID = 536870915;
        public const int SYS_CREATOR_ORG_GROUP_ID = 536870952;
        public const int SEND_EMAIL_ON_CREATION = 536870923;
        public const int ALLOW_ATTACHMENTS = 536870941;
        public const int SET_ORIGINAL_SENDER_AS_CUSTOMER = 536870942;


        public UNCRSEmailIn(BMC.ARSystem.Server ARServer, string emailAddress)
        {
            /* Add fields to list to be retrieved by query*/
            _fields = new EntryListFieldList();
            _fields.AddField(STATUS);
            _fields.AddField(EMAIL_IDENTIFICATION);
            _fields.AddField(ORGANIZATION_GROUP);
            _fields.AddField(STATUS1);
            _fields.AddField(SEND_EMAIL_TO_CLIENT);
            _fields.AddField(FOLLOW_UP_EMAIL);
            _fields.AddField(SYS_AFFILIATION);
            _fields.AddField(STUDENT_OR_OTHERS);
            _fields.AddField(PID);
            _fields.AddField(LAST_NAME);
            _fields.AddField(FIRST_NAME);
            _fields.AddField(MIDDLE_INITIAL);
            _fields.AddField(SOURCE);
            _fields.AddField(PHONE);
            _fields.AddField(EMAIL);
            _fields.AddField(SHORT_DESCRIPTION);
            _fields.AddField(CATEGORY);
            _fields.AddField(GROUP_ASSIGNED);
            _fields.AddField(PROBLEM_DESCRIPTION);
            _fields.AddField(TOPIC_AFFECTED);
            _fields.AddField(ITEM_AFFECTED);
            _fields.AddField(PERSON_ASSIGNED);
            _fields.AddField(SEVERITY_MENU);
            _fields.AddField(ORG_ID);
            _fields.AddField(SYS_CREATOR_ORG_GROUP_ID);
            _fields.AddField(SEND_EMAIL_ON_CREATION);
            _fields.AddField(ALLOW_ATTACHMENTS);
            _fields.AddField(SET_ORIGINAL_SENDER_AS_CUSTOMER);


            _query = "'" + EMAIL_IDENTIFICATION.ToString() + "' = \"" + emailAddress + "\" AND '" + STATUS.ToString() + "' = 0"; // Build Query
            _results = ARServer.GetListEntryWithFields("UNC-RS-Email-In", _query, _fields, 0, 0); // Actually Query The Form
        }


        public EntryFieldValueList getEverything
        {
            get
            {
                return _results;
            }
        }
        public String GetStatus
        {
            get
            {
                if (_results[0].FieldValues[STATUS] != null)
                {
                    return _results[0].FieldValues[STATUS].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetEmailIdentification
        {
            get
            {
                if (_results[0].FieldValues[EMAIL_IDENTIFICATION] != null)
                {
                    return _results[0].FieldValues[EMAIL_IDENTIFICATION].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetOrganizationGroup
        {
            get
            {
                if (_results[0].FieldValues[ORGANIZATION_GROUP] != null)
                {
                    return _results[0].FieldValues[ORGANIZATION_GROUP].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetStatus1
        {
            get
            {
                if (_results[0].FieldValues[STATUS1] != null)
                {
                    return _results[0].FieldValues[STATUS1].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetSendEmailToClient
        {
            get
            {
                if (_results[0].FieldValues[SEND_EMAIL_TO_CLIENT] != null)
                {
                    return _results[0].FieldValues[SEND_EMAIL_TO_CLIENT].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetFollowUpEmail
        {
            get
            {
                if (_results[0].FieldValues[FOLLOW_UP_EMAIL] != null)
                {
                    return _results[0].FieldValues[FOLLOW_UP_EMAIL].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetSysAffiliation
        {
            get
            {
                if (_results[0].FieldValues[SYS_AFFILIATION] != null)
                {
                    return _results[0].FieldValues[SYS_AFFILIATION].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetStudentOrOthers
        {
            get
            {
                if (_results[0].FieldValues[STUDENT_OR_OTHERS] != null)
                {
                    return _results[0].FieldValues[STUDENT_OR_OTHERS].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetPID
        {
            get
            {
                if (_results[0].FieldValues[PID] != null)
                {
                    return _results[0].FieldValues[PID].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetLastName
        {
            get
            {
                if (_results[0].FieldValues[LAST_NAME] != null)
                {
                    return _results[0].FieldValues[LAST_NAME].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetFirstName
        {
            get
            {
                if (_results[0].FieldValues[FIRST_NAME] != null)
                {
                    return _results[0].FieldValues[FIRST_NAME].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetMiddleInitial
        {
            get
            {
                if (_results[0].FieldValues[MIDDLE_INITIAL] != null)
                {
                    return _results[0].FieldValues[MIDDLE_INITIAL].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetSource
        {
            get
            {
                if (_results[0].FieldValues[SOURCE] != null)
                {
                    return _results[0].FieldValues[SOURCE].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetPhone
        {
            get
            {
                if (_results[0].FieldValues[PHONE] != null)
                {
                    return _results[0].FieldValues[PHONE].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetEmail
        {
            get
            {
                if (_results[0].FieldValues[EMAIL] != null)
                {
                    return _results[0].FieldValues[EMAIL].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetShortDescription
        {
            get
            {
                if (_results[0].FieldValues[SHORT_DESCRIPTION] != null)
                {
                    return _results[0].FieldValues[SHORT_DESCRIPTION].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetCategory
        {
            get
            {
                if (_results[0].FieldValues[CATEGORY] != null)
                {
                    return _results[0].FieldValues[CATEGORY].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetGroupAssigned
        {
            get
            {
                if (_results[0].FieldValues[GROUP_ASSIGNED] != null)
                {
                    return _results[0].FieldValues[GROUP_ASSIGNED].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetProblemDescription
        {
            get
            {
                if (_results[0].FieldValues[PROBLEM_DESCRIPTION] != null)
                {
                    return _results[0].FieldValues[PROBLEM_DESCRIPTION].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetTopicAffected
        {
            get
            {
                if (_results[0].FieldValues[TOPIC_AFFECTED] != null)
                {
                    return _results[0].FieldValues[TOPIC_AFFECTED].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetItemAffected
        {
            get
            {
                if (_results[0].FieldValues[ITEM_AFFECTED] != null)
                {
                    return _results[0].FieldValues[ITEM_AFFECTED].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetPersonAssigned
        {
            get
            {
                if (_results[0].FieldValues[PERSON_ASSIGNED] != null)
                {
                    return _results[0].FieldValues[PERSON_ASSIGNED].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetSeverityMenu
        {
            get
            {
                if (_results[0].FieldValues[SEVERITY_MENU] != null)
                {
                    return _results[0].FieldValues[SEVERITY_MENU].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetOrgID
        {
            get
            {
                if (_results[0].FieldValues[ORG_ID] != null)
                {
                    return _results[0].FieldValues[ORG_ID].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetSysCratorOrgGroupID
        {
            get
            {
                if (_results[0].FieldValues[SYS_CREATOR_ORG_GROUP_ID] != null)
                {
                    return _results[0].FieldValues[SYS_CREATOR_ORG_GROUP_ID].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetSendEmailOnCreation
        {
            get
            {
                if (_results[0].FieldValues[SEND_EMAIL_ON_CREATION] != null)
                {
                    return _results[0].FieldValues[SEND_EMAIL_ON_CREATION].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetAllowAttachment
        {
            get
            {
                if (_results[0].FieldValues[ALLOW_ATTACHMENTS] != null)
                {
                    return _results[0].FieldValues[ALLOW_ATTACHMENTS].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }
        public String GetSetOriginalSenderAsCustomer
        {
            get
            {
                if (_results[0].FieldValues[SET_ORIGINAL_SENDER_AS_CUSTOMER] != null)
                {
                    return _results[0].FieldValues[SET_ORIGINAL_SENDER_AS_CUSTOMER].ToString();
                }
                else
                {
                    return "Unknown";
                }
            }
        }

    }

}