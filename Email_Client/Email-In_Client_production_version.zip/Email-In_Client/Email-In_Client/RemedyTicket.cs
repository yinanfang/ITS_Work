﻿using BMC.ARSystem;
using HtmlAgilityPack;
using Microsoft.Exchange.WebServices.Data;
using NLog;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Email_In_Client
{
	class RemedyTicket
	{
		// EWS
		private static EmailMessage message;
		// Remedy
		private static BMC.ARSystem.Server ARServer;
		// Ticket
		FieldValueList fields;
		private static string onyen;
		private static string ticketNumber_str;
		private static string ticket_body;
		private static string form_RFS = "UNC-Request for Service";
		private static bool hasValidAttachment;
        private static bool hasOnyen;

        // Loopup
        private static RemedyDirectoryLDAP LDAPLoopUp;
        private static UNCRSEmailIn CRSEmailInLoopUp;


		// NLog
		private static Logger logger = LogManager.GetCurrentClassLogger();
		private static string log_msg;

		// ******************************************************************************************************************************************************
		// Constructor
		// ******************************************************************************************************************************************************
		// Empty constructor
		public RemedyTicket()
		{
		}

		// Constructor for updating ticket
		public RemedyTicket(BMC.ARSystem.Server server, EmailMessage msg, string ticketNum, string onyen_str)
		{
			ARServer = server;
			message = msg;
			ticketNumber_str = ticketNum;
			onyen = onyen_str;
			// Reset ticket variables for new ticket
			hasValidAttachment = false;
			ticket_body = "";
			fields = new FieldValueList();
		}

        // Constructor for creating new ticket
        public RemedyTicket(BMC.ARSystem.Server server, EmailMessage msg, string onyen_str, bool hasFoundOnyen)
        {
            ARServer = server;
            message = msg;
            onyen = onyen_str;
            hasOnyen = hasFoundOnyen;
            // Reset ticket variables for new ticket
            hasValidAttachment = false;
            ticket_body = "";
            fields = new FieldValueList();
        }

        // ******************************************************************************************************************************************************
        // Create a new ticket
        // ******************************************************************************************************************************************************
        public bool CreateNewTicket()
        {
            try
            {
                // Instatiate the lookup
                LDAPLoopUp = new RemedyDirectoryLDAP(ARServer, onyen);
                CRSEmailInLoopUp = new UNCRSEmailIn(ARServer, Remedy_Service.email_withActiveEntry);
                ticket_body = getCleanMessageBody(message);
                handleAttachment_create();
				Console.WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>Current tickey body");
				Console.WriteLine(ticket_body);
				Console.WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
                Console.WriteLine("Filling the rest of the fields...");
                if (hasOnyen)
                {
                    Console.WriteLine("The Onyen is: " + onyen);
                    fillInFieldsWithLDAPInfo();
                }
                else
                {
                    Console.WriteLine("No Onyen. Email is:  " + onyen);
                    fillInFieldsWithEmailInDefaultInfo();
                }
                //process of actually submiting values and generating ticket
                ticketNumber_str = ARServer.CreateEntry(form_RFS, fields);
                Console.WriteLine("Successfully created ticket with number: " + ticketNumber_str);
                fields.Clear();
                return true;
            }
            catch (Exception ex)
            {
                log_msg = "Error! Unable to create new ticket... \nError: " + ex.Message + "\nException type: " + ex.GetType().FullName;
                Console.WriteLine(log_msg);
                logger.Fatal(log_msg);
                return false;
            }
        }

        private void fillInFieldsWithLDAPInfo()
        {
            Console.WriteLine("Filling customer info...");
            // Customer Contact Info
            fields.Add(RfsFields.CUSTOMER_ONYEN, onyen);
            fields.Add(RfsFields.CUSTOMER_PID, LDAPLoopUp.GetPID);                                      // required
           

            fields.Add(RfsFields.CUSTOMER_DEPARTMENT, LDAPLoopUp.GetDepartment);
            fields.Add(RfsFields.CUSTOMER_LAST_NAME, LDAPLoopUp.GetLastName);                           // required
            fields.Add(RfsFields.CUSTOMER_FIRST_NAME, LDAPLoopUp.GetFirstName);                         // required

            string MiddleInitial = LDAPLoopUp.GetMI;
            if (MiddleInitial == null | MiddleInitial.Equals(""))
            {
                MiddleInitial = "x";
            }
            fields.Add(RfsFields.CUSTOMER_MIDDLE_INITIAL, MiddleInitial);

            string Affiliation = LDAPLoopUp.GetType1;
            if (Affiliation == "3" || Affiliation == null || Affiliation == "")                                //this is to fix that issue with folks that have STAFF-STUDENT as their type in Remedy LDAP
            {
                Affiliation = "0";
            }
            fields.Add(RfsFields.CUSTOMER_AFFILIATION, Affiliation);                      // Required - 1= fac/staff

            string PhoneNumber = LDAPLoopUp.GetPhoneNumber;
            if (PhoneNumber == null | PhoneNumber.Equals(""))
            {
                PhoneNumber = "x";
            }
            fields.Add(RfsFields.CUSTOMER_TELEPHONE, PhoneNumber);                        // Required
            fields.Add(RfsFields.CUSTOMER_EMAIL, LDAPLoopUp.GetEmail);
            fields.Add(RfsFields.CUSTOMER_LOCATION, LDAPLoopUp.GetLocation);

            // CITI's
            Console.WriteLine("Filling CITI info...");
            string ShortDescription = CRSEmailInLoopUp.GetShortDescription;
            if (ShortDescription == "Blank")
            {
                ShortDescription = message.Subject;
            }
            fields.Add(RfsFields.SHORT_DESCRIPTION, ShortDescription);               // Required - Main dropdown
            
            fields.Add(RfsFields.CATEGORY, CRSEmailInLoopUp.GetCategory);                        //required, has to match group values
            fields.Add(RfsFields.TOPIC_AFFECTED, CRSEmailInLoopUp.GetTopicAffected);
            fields.Add(RfsFields.ITEM_AFFECTED, CRSEmailInLoopUp.GetItemAffected);

            string ProblemDescription = CRSEmailInLoopUp.GetProblemDescription;
            if (ProblemDescription == null)
            {
                ProblemDescription = message.Subject;
            }
            fields.Add(RfsFields.CLIENTS_PROBLEM_DESCRIPTION, ProblemDescription);     // Cap at 250char

            //Request Info
            Console.WriteLine("Filling request info...");
            fields.Add(RfsFields.SEVERITY, CRSEmailInLoopUp.GetSeverityMenu);
            fields.Add(RfsFields.WORKLOG, ticket_body);
            fields.Add(RfsFields.FOLLOW_UP_EMAIL, CRSEmailInLoopUp.GetFollowUpEmail);
            fields.Add(RfsFields.CREATOR, "emailinnet");
            fields.Add(RfsFields.GROUP_ASSIGNED, CRSEmailInLoopUp.GetGroupAssigned);                      //Required          

            string PersonAssigned = CRSEmailInLoopUp.GetPersonAssigned;
            if (PersonAssigned != "")
	        {
		        fields.Add(RfsFields.PERSON_ASSIGNED, PersonAssigned); 
	        }

            fields.Add(RfsFields.GROUP_CREATED, "WEBSUBMIT");
            fields.Add(RfsFields.STATUS, CRSEmailInLoopUp.GetStatus1);
            //fields.Add(RfsFields.EMAILTO, LDAPLoopUp.GetEmail);
            //fields.Add(RfsFields.EMAILREPLYTO, "");
            //fields.Add(RfsFields.EMAILCC, "");
            //fields.Add(RfsFields.EMAILTEXT, "");
            //fields.Add(RfsFields.EMAILWORKLOG, "No");
            fields.Add(RfsFields.POINT_OF_CONTACT, "Email");
            fields.Add(RfsFields.EMAIL_UPDATES, "Yes");
            fields.Add(RfsFields.SOURCE, "1");  // Required, UInteger, 1 = email
            fields.Add(RfsFields.IP_ADDRESS, "");

            //Sys Fields           
            Console.WriteLine("Filling System fields info...");
            fields.Add(RfsFields.SYS_CREATORORGROUPID, "2406");
            fields.Add(RfsFields.SYS_ORGGROUP_ID, "63");
            fields.Add(RfsFields.SYS_EMAIL_FLAG, "");
            fields.Add(RfsFields.SYS_ACK, "0");
            fields.Add(RfsFields.MODIFIED, "COM-.NET");
            fields.Add(RfsFields.SYS_PERL_SCRIPT_CREATED, "COM-.NET");
            fields.Add(RfsFields.SYS_EMAIL_IN_SENDEMAIL, "Yes");
            fields.Add(RfsFields.SYS_TEMPLATE, "Email-In");

            
        }

        private void fillInFieldsWithEmailInDefaultInfo()
        {
            Console.WriteLine("Filling customer info...");
            // Customer Contact Info
            fields.Add(RfsFields.CUSTOMER_ONYEN, "x");
            fields.Add(RfsFields.CUSTOMER_PID, CRSEmailInLoopUp.GetPID);                                      // required


            //fields.Add(RfsFields.CUSTOMER_DEPARTMENT, CRSEmailInLoopUp.GetDepartment);
            fields.Add(RfsFields.CUSTOMER_LAST_NAME, CRSEmailInLoopUp.GetLastName);                           // required
            fields.Add(RfsFields.CUSTOMER_FIRST_NAME, CRSEmailInLoopUp.GetFirstName);                         // required

            string MiddleInitial = CRSEmailInLoopUp.GetMiddleInitial;
            if (MiddleInitial == null | MiddleInitial.Equals(""))
            {
                MiddleInitial = "x";
            }
            fields.Add(RfsFields.CUSTOMER_MIDDLE_INITIAL, MiddleInitial);

            string StudentOrOthers = CRSEmailInLoopUp.GetStudentOrOthers;
            if (StudentOrOthers == "3" || StudentOrOthers == null || StudentOrOthers == "")                                //this is to fix that issue with folks that have STAFF-STUDENT as their type in Remedy LDAP
            {
                StudentOrOthers = "0";
            }
            fields.Add(RfsFields.CUSTOMER_AFFILIATION, StudentOrOthers);                      // Required - 1= fac/staff

            string PhoneNumber = CRSEmailInLoopUp.GetPhone;
            if (PhoneNumber == null | PhoneNumber.Equals(""))
            {
                PhoneNumber = "x";
            }
            fields.Add(RfsFields.CUSTOMER_TELEPHONE, PhoneNumber);                        // Required
            
            fields.Add(RfsFields.CUSTOMER_EMAIL, CRSEmailInLoopUp.GetEmail);
            //fields.Add(RfsFields.CUSTOMER_LOCATION, CRSEmailInLoopUp.GetLocation);

            //CTI's
            Console.WriteLine("Filling CITI info...");
            string ShortDescription = CRSEmailInLoopUp.GetShortDescription;
            if (ShortDescription == "Blank")
            {
                ShortDescription = message.Subject;
            }
            fields.Add(RfsFields.SHORT_DESCRIPTION, ShortDescription);               // Required - Main dropdown
            fields.Add(RfsFields.CATEGORY, CRSEmailInLoopUp.GetCategory);                        //required, has to match group values
            fields.Add(RfsFields.TOPIC_AFFECTED, CRSEmailInLoopUp.GetTopicAffected);
            fields.Add(RfsFields.ITEM_AFFECTED, CRSEmailInLoopUp.GetItemAffected);

            string ProblemDescription = CRSEmailInLoopUp.GetProblemDescription;
            if (ProblemDescription == null)
            {
                ProblemDescription = message.Subject;
            }
            fields.Add(RfsFields.CLIENTS_PROBLEM_DESCRIPTION, ProblemDescription);     // Cap at 250char

            //Request Info
            Console.WriteLine("Filling request info...");
            fields.Add(RfsFields.SEVERITY, CRSEmailInLoopUp.GetSeverityMenu);
            fields.Add(RfsFields.WORKLOG, ticket_body);
            fields.Add(RfsFields.FOLLOW_UP_EMAIL, CRSEmailInLoopUp.GetFollowUpEmail);
            fields.Add(RfsFields.CREATOR, "emailinnet");
            fields.Add(RfsFields.GROUP_ASSIGNED, CRSEmailInLoopUp.GetGroupAssigned);                      //Required          
            string PersonAssigned = CRSEmailInLoopUp.GetPersonAssigned;
            if (PersonAssigned != "")
            {
                fields.Add(RfsFields.PERSON_ASSIGNED, PersonAssigned);
            }
            fields.Add(RfsFields.GROUP_CREATED, "WEBSUBMIT");
            fields.Add(RfsFields.STATUS, CRSEmailInLoopUp.GetStatus1);
            fields.Add(RfsFields.EMAILTO, CRSEmailInLoopUp.GetEmail);
            //fields.Add(RfsFields.EMAILREPLYTO, "");
            //fields.Add(RfsFields.EMAILCC, "");
            //fields.Add(RfsFields.EMAILTEXT, "");
            //fields.Add(RfsFields.EMAILWORKLOG, "No");
            fields.Add(RfsFields.POINT_OF_CONTACT, "Email");
            fields.Add(RfsFields.EMAIL_UPDATES, "Yes");
            fields.Add(RfsFields.SOURCE, "1");  // Required, UInteger, 1 = email
            fields.Add(RfsFields.IP_ADDRESS, "");

            //Sys Fields    
            Console.WriteLine("Filling System fields info...");
            fields.Add(RfsFields.SYS_CREATORORGROUPID, "2406");
            fields.Add(RfsFields.SYS_ORGGROUP_ID, "63");
            fields.Add(RfsFields.SYS_EMAIL_FLAG, "");
            fields.Add(RfsFields.SYS_ACK, "0");
            fields.Add(RfsFields.MODIFIED, "COM-.NET");
            fields.Add(RfsFields.SYS_PERL_SCRIPT_CREATED, "COM-.NET");
            fields.Add(RfsFields.SYS_EMAIL_IN_SENDEMAIL, "Yes");
            fields.Add(RfsFields.SYS_TEMPLATE, "Email-In");


        }

		// ******************************************************************************************************************************************************
		// Update a ticket
		// ******************************************************************************************************************************************************
		public bool UpdateExistingTicket()
		{
			try
			{
				ticket_body = getCleanMessageBody(message);
				handleAttachment_update();
				Console.WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>Current tickey body");
				Console.WriteLine(ticket_body);
				Console.WriteLine(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
				// Update Worklog
				fields.Add(RfsFields.TICKET_NUMBER, ticketNumber_str);
				fields.Add(RfsFields.WORKLOG, ticket_body);
				ARServer.SetEntry(form_RFS, ticketNumber_str, fields);
				return true;
			}
			catch (Exception ex)
			{
				log_msg = "Unable to update ticket worklog... \nError: " + ex.Message + "\nException type: " + ex.GetType().FullName;
				Console.WriteLine(log_msg);
				logger.Fatal(log_msg);
				return false;
			}
		}
		// ******************************************************************************************************************************************************
		// Reusable public method
		// ******************************************************************************************************************************************************
		public string getCleanMessageBody(EmailMessage message)
		{
			// Use HtmlAgilityPack to clean up HTML tags
			HtmlDocument doc = new HtmlDocument();
			doc.LoadHtml(message.Body);
			StringBuilder str_modified = new StringBuilder();
			foreach (HtmlTextNode node in doc.DocumentNode.SelectNodes("//text()"))
			{
				str_modified.AppendLine(node.Text);
			}
			ticket_body = str_modified.ToString();
			// Take out HTML comment
			ticket_body = Regex.Replace(ticket_body, @"<!--.*?-->", "", RegexOptions.Singleline);
			// Take out empty lines
			ticket_body = Regex.Replace(ticket_body, @"^\s+$[\r\n*]", "", RegexOptions.Multiline);
			// Take out &nbsp; 
			ticket_body = Regex.Replace(ticket_body, @"&nbsp;", " ", RegexOptions.Multiline);
			// Take out &amp; 
			ticket_body = Regex.Replace(ticket_body, @"&amp;", "&", RegexOptions.Multiline);
			return ticket_body;
		}

		public bool hasAttachment(EmailMessage message)
		{
			if (message.Attachments.Count > 0)
			{
				Console.WriteLine("Has attachment(s)...");
				return true;
			}
			else
			{
				Console.WriteLine("No attachment...");
				return false;
			}

		}

        private void handleAttachment_create()
        {
            // Check and Add attachments
            if (hasAttachment(message))
            {
                BMC.ARSystem.Attachment attach = getAttachments(message);
                if (attach == null)
                {
                    Console.WriteLine("Invalid attachment...");
                }
                else
                {
                    Console.WriteLine("Valid attachment...");
                    Console.WriteLine("the size is : " + attach.CompSize.ToString());
                    
                    if (CRSEmailInLoopUp.GetAllowAttachment.ToString() == "1")
                    {
                        fields.Add(RfsFields.ATTACHMENT_1, attach);
                    }
                    else
                    {
                        
                    }
                    
                }
            }
        }

		private void handleAttachment_update()
		{
            // Check and Add attachments
			if (hasAttachment(message))
			{
				BMC.ARSystem.Attachment attach = getAttachments(message);
				if (attach == null)
				{
					Console.WriteLine("Invalid attachment...");
				}
				else
				{
					Console.WriteLine("Valid attachment...");
					Console.WriteLine("the size is : " + attach.CompSize.ToString());
					getRFSInfo getTicket = new getRFSInfo(ARServer, ticketNumber_str, form_RFS);
					if (getTicket.getEverything[0].FieldValues[RfsFields.ATTACHMENT_1] == null || getTicket.getEverything[0].FieldValues[RfsFields.ATTACHMENT_1].Equals(System.DBNull.Value))
					{
						fields.Add(RfsFields.ATTACHMENT_1, attach);
						Console.WriteLine("Added attachment to field ATTACHMENT_1");
					}
					else if (getTicket.getEverything[0].FieldValues[RfsFields.ATTACHMENT_2] == null || getTicket.getEverything[0].FieldValues[RfsFields.ATTACHMENT_2].Equals(System.DBNull.Value))
					{
						fields.Add(RfsFields.ATTACHMENT_2, attach);
						Console.WriteLine("Added attachment to field ATTACHMENT_2");
					}
					else if (getTicket.getEverything[0].FieldValues[RfsFields.ATTACHMENT_3] == null || getTicket.getEverything[0].FieldValues[RfsFields.ATTACHMENT_3].Equals(System.DBNull.Value))
					{
						fields.Add(RfsFields.ATTACHMENT_3, attach);
						Console.WriteLine("Added attachment to field ATTACHMENT_3");
					}
					else if (getTicket.getEverything[0].FieldValues[RfsFields.ATTACHMENT_4] == null || getTicket.getEverything[0].FieldValues[RfsFields.ATTACHMENT_4].Equals(System.DBNull.Value))
					{
						fields.Add(RfsFields.ATTACHMENT_4, attach);
						Console.WriteLine("Added attachment to field ATTACHMENT_4");
					}
					else if (getTicket.getEverything[0].FieldValues[RfsFields.ATTACHMENT_5] == null || getTicket.getEverything[0].FieldValues[RfsFields.ATTACHMENT_5].Equals(System.DBNull.Value))
					{
						fields.Add(RfsFields.ATTACHMENT_5, attach);
						Console.WriteLine("Added attachment to field ATTACHMENT_5");
					}
					else
					{
						Console.WriteLine("All attachment fields are full. Excessive attachment is abandoned...");
						ticket_body = "attachment name" + "\n" + ticket_body;
					}
				}
			}
		}

		public BMC.ARSystem.Attachment getAttachments(EmailMessage message)
		{
			Microsoft.Exchange.WebServices.Data.Attachment attachment;
			BMC.ARSystem.Attachment attach_Remedy = null;
			int attachment_count = message.Attachments.Count;

			Console.WriteLine("Getting the attachments..."); 
			string email_In_folder = @"C:\\websubmituploads\\email_in";
			string folderNameWith_TimeAndOnyen = DateTime.Now.ToString("yyyy-M-d_hh-mm-ss") + "_" + onyen;
			string startPath = @"C:\\websubmituploads\\email_in\\" + folderNameWith_TimeAndOnyen;
			string zipPath = @"C:\\websubmituploads\\email_in\\" + folderNameWith_TimeAndOnyen + ".zip";

			if (System.IO.Directory.Exists(email_In_folder))
			{
				Directory.Delete(email_In_folder, true);
			}
			System.IO.Directory.CreateDirectory(email_In_folder);
			System.IO.Directory.CreateDirectory(startPath);

			for (int i = 0; i < attachment_count; i++)
			{
				attachment = message.Attachments[i];
				if (attachment.Size > 512000)           // size < 500kb
				{
					string error_msg = "Attachment: " + attachment.Name + " is larger than 500kb and rejected by the server...";
					Console.WriteLine(error_msg);
					ticket_body = error_msg + "\n\n" + ticket_body;
				}
				else 
				{
					string[] validFileTypes = System.Configuration.ConfigurationManager.AppSettings["FileTypes"].Split(new string[] { ", " }, StringSplitOptions.None);
					string attachmentName = attachment.Name;
					bool isValidFile = false;
					string fileType;
					//check extension
					for (int j = 0; j < validFileTypes.Length; j++)
					{
						fileType = validFileTypes[j].ToLower();
						if (attachmentName.Contains(fileType))
						{
							Console.WriteLine("Valid attachment...");
							isValidFile = true;
							hasValidAttachment = true;
							// Save file to drive
							FileAttachment fileattach = attachment as FileAttachment;
							string file_path = startPath + "\\" + fileattach.Name;
							Console.WriteLine("Save file to drive with name: " + file_path);
							fileattach.Load(file_path);
							break;
						}
					}
					if (!isValidFile)
					{
						string error_msg = "Attachment: " + attachment.Name + " is of invalid file type and rejected by the server...";
						Console.WriteLine(error_msg);
						ticket_body = error_msg + "\n\n" + ticket_body;
					}
				}
			}
			ZipFile.CreateFromDirectory(startPath, zipPath);
			// Check if the zip file exceeds the size limit
			FileInfo file = new FileInfo(zipPath);
			if (hasValidAttachment)
			{
			   if (file.Length > 512000)
				{
					hasValidAttachment = false;
					string error_msg = "The totoal size of the attachments is larger than 500 kb and rejected by the server...";
					Console.WriteLine(error_msg);
					ticket_body = error_msg + "\n\n" + ticket_body;
				} 
			}
			if (hasValidAttachment)
			{
				// Get file from drive
				attach_Remedy = new BMC.ARSystem.Attachment(zipPath);
			}
			//Console.ReadKey(true);
			Directory.Delete(startPath, true);
			File.Delete(zipPath);
			return attach_Remedy;
		}

		
	}
}
