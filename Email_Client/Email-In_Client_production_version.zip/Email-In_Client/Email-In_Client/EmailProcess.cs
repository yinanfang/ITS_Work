﻿using Microsoft.Exchange.WebServices.Data;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Email_In_Client
{
    public class EmailProcess
    {
        // EWSService
        private static EWS_Service EWSService;

        // RemedyService
        private static Remedy_Service RemedyService;
        private static BMC.ARSystem.Server ARServer;

        // Global variable for processing email item
        private static EmailMessage message;
        private static string subject;
        private static string email;
        private static string onyen;
        private static string ticketNumber_str;

        // NLog
        private static Logger logger = LogManager.GetCurrentClassLogger();
        private static string log_msg;

        // Empty constructor
        public EmailProcess() { }

        // Main processing method
        public void startProcessingEmails()
        {
            // Service Initialization
            if (!initEWSAndRemedyService())
            {
                log_msg = "Email-In Client aborted due to errors occured during the EWS service and Remedy service initialization.";
                Console.WriteLine("\n" + log_msg);
                logger.Fatal(log_msg);
            }
            else
            {
                log_msg = "EWS service and Remedy service initialization completed...";
                Console.WriteLine("\n" + log_msg);
                logger.Info(log_msg);

                // Start connection
                if (!loopThroughUnreadEmails())
                {
                    log_msg = "Email-In Client aborted due to errors occured when looping through unread emails in Inbox.";
                    Console.WriteLine("\n" + log_msg);
                    logger.Fatal(log_msg);
                }
                else
                {
                    log_msg = "Successfully loop through all unread emails in Inbox. Scheduled process completed...";
                    Console.WriteLine("\n" + log_msg);
                    logger.Info(log_msg);
                }
                


            }
        }

        private bool initEWSAndRemedyService()
        {
            // EWS
            EWSService = new EWS_Service();
            if (!EWSService.initEWSService())
            {
                // Check if initialization fails
                return false;
            }

            // Remedy
            RemedyService = new Remedy_Service();
            if (!RemedyService.initRemedyService())
            {                
                // Check if initialization fails
                return false;
            }

            // Initialization succeeded
            ARServer = Remedy_Service.ARServer;
            return true;

        }

        private bool loopThroughUnreadEmails()
        {
            try
            {
                FindItemsResults<Item> unreadItems = EWSService.getUnreadItems();
                int unreadItems_count = unreadItems.TotalCount;
                string log_msg = "Number of unread email about to be processed: " + unreadItems_count.ToString();
                Console.WriteLine("\n" + log_msg);
                logger.Info(log_msg);

                foreach (EmailMessage msg in unreadItems)
                {
                    try
                    {
                        Console.WriteLine("\n\n======================================================================================================================");
                        Console.WriteLine("Reading messages...");
                        message = msg;
                        message.Load();
                        subject = (message.Subject == null) ? "" : message.Subject;
                        email = (message.Sender.Address == null) ? "No@Address" : message.Sender.Address;
                        onyen = EWSService.loopUpOnyen(email);
                        Console.WriteLine("From: " + email + "\nSubject: " + subject);
                        if (EWSService.isSystemEmail(email))
                        {
                            Console.WriteLine(">>>Ignoring system emails...");
                        }
                        else if (EWSService.hasTicketNumber(subject))
                        {
                            ticketNumber_str = "00000000" + Regex.Match(subject, @"\d+").Value;
                            Console.WriteLine("Has ticket number: " + ticketNumber_str);
                            if (!RemedyService.isValidTicketNumber(ticketNumber_str))
                            {
                                Console.WriteLine("NOT a valid ticket number");
                                EWSService.moveMessageToNotProcessed(message);
                            }
                            else
                            {
                                Console.WriteLine("VALID ticket number");
                                processExistingTicket();
                                EWSService.moveMessageToProcessed(message);
                            }
                        }
                        else
                        {
                            Console.WriteLine("No ticket number. It's an new ticket.");


                            if (!RemedyService.hasActiveEntry(message))
                            {
                                Console.WriteLine("NO Active entry... ");
                                EWSService.moveMessageToNotProcessed(message);
                            }
                            else
                            {
                                Console.WriteLine("Found Active entry... ");
                                createNewTicket();
                                EWSService.moveMessageToProcessed(message);
                            }
                        }
                        Console.WriteLine("======================================================================================================================");
                    }
                    catch (Exception ex)
                    {
                        log_msg = "Error! Unable to process specific email: " + ((message.Subject == null) ? "" : message.Subject) + " \nError: " + ex.Message + "\nException type: " + ex.GetType().FullName;
                        Console.WriteLine(log_msg);
                        logger.Fatal(log_msg);
                        EWSService.moveMessageToNotProcessed(msg);
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                log_msg = "Error! Unable to process emails... \nError: " + ex.Message + "\nException type: " + ex.GetType().FullName;
                Console.WriteLine(log_msg);
                logger.Fatal(log_msg);
                return false;
            }  
        }

        private void processExistingTicket()
        {
            // Update worklog of existing ticket

            RemedyTicket ticket = new RemedyTicket(ARServer, message, ticketNumber_str, onyen);
            if (ticket.UpdateExistingTicket())
            {
                Console.WriteLine("Updated ticket {0} successfully...", ticketNumber_str);
            }
            else
            {
                Console.WriteLine("Error occurs when updating ticket {0}...", ticketNumber_str);
            }
            
        }

        private void createNewTicket()
        {
            // Get original or forwarded sender and set the onyen
            string email_sender_prefered;
            Match isFWed = Regex.Match(subject, @"^FW:.+$", RegexOptions.None);
            if (!isFWed.Success)
            {
                Console.WriteLine("Email is original... ");
                email_sender_prefered = (message.Sender.Address == null) ? "No@Address" : message.Sender.Address;
            }
            else
            {
                Console.WriteLine("Email is forwarded... ");
                // Get the original sender in the forwarded email
                email_sender_prefered = EWSService.getOriginalSender(message);
            }
            // AD loopup
            onyen = EWSService.loopUpOnyen(email_sender_prefered);
            RemedyTicket ticket;
            if (onyen.Contains("@"))
            {
                Console.WriteLine("AD look up failed. Use default info from Email-In...");
                ticket = new RemedyTicket(ARServer, message, onyen, false);
            }
            else
            {
                Console.WriteLine("Found Onyen. Use Remedy API to do lookup...");
                ticket = new RemedyTicket(ARServer, message, onyen, true);
            }
            if (ticket.CreateNewTicket())
            {
                Console.WriteLine("Created ticket successfully...");
            }
            else
            {
                Console.WriteLine("Error occurs when creating ticket...");
            }
        }


    }
}
